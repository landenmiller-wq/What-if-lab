// Run with: node --test test/
const test = require('node:test');
const assert = require('node:assert/strict');
const E = require('../src/engine.js');

const close = (a, b, tol = 1e-6, msg) => assert.ok(Math.abs(a - b) <= tol * Math.max(1, Math.abs(b)), `${msg || ''} expected ${b}, got ${a}`);

// A flat, simple business whose results can be computed by hand.
function flatCo(extra = {}) {
  const DPM = E.DPM;
  const history = Array.from({ length: 12 }, (_, i) => ({ month: `M${i + 1}`, revenue: 100000, cogs: 40000, payroll: 30000, rent: 10000, otherOpex: 5000 }));
  return Object.assign({
    history,
    balance: {
      cash: 50000, ar: 100000 * 30 / DPM, inventory: 40000 * 45 / DPM, otherCurrentAssets: 0,
      fixedAssets: 100000, otherAssets: 0, ap: 40000 * 30 / DPM, accrued: 0, debt: 0, debtApr: 0, debtPayment: 0,
    },
    taxRate: 0.25, depreciation: 1000, capex: 0, costInflation: 0,
  }, extra);
}

test('loan payment formula matches the standard annuity result', () => {
  close(E.pmt(0.01, 12, 1000), 88.84878868, 1e-8);
  close(E.pmt(0, 10, 1000), 100);
});

test('linear regression recovers an exact line', () => {
  const r = E.linreg([0, 1, 2, 3], [1, 3, 5, 7]);
  close(r.slope, 2); close(r.intercept, 1); close(r.residualSD, 0);
});

test('percentile uses linear interpolation', () => {
  close(E.percentile([1, 2, 3, 4], 50), 2.5);
  close(E.percentile([1, 2, 3, 4, 5], 10), 1.4);
});

test('assumptions derived from flat history', () => {
  const A = E.deriveAssumptions(flatCo());
  close(A.growth, 0); close(A.revVol, 0); close(A.grossMargin, 0.6);
  close(A.fixedOpex, 45000); close(A.dso, 30); close(A.dio, 45); close(A.dpo, 30);
});

test('today ratios computed by hand', () => {
  const t = E.analyzeToday(flatCo());
  // Annual: revenue 1.2M, GP 720k, opex 540k, EBITDA 180k, dep 12k, EBIT 168k, tax 42k, NI 126k
  close(t.flows.netIncome, 126000);
  close(t.ratios.netMargin, 0.105);
  close(t.ratios.grossMargin, 0.6);
  const b = flatCo().balance;
  const ca = b.cash + b.ar + b.inventory;
  close(t.ratios.currentRatio, ca / b.ap);
  close(t.ratios.quickRatio, (b.cash + b.ar) / b.ap);
  const ta = ca + b.fixedAssets;
  close(t.ratios.roa, 126000 / ta);
  close(t.ratios.roe, 126000 / (ta - b.ap));
  close(t.ratios.cashConversionCycle, 30 + 45 - 30);
  assert.equal(t.ratios.debtToEquity, 0);
  assert.equal(t.ratios.runwayMonths, null); // cash generative
});

test('expected projection of the flat business', () => {
  const co = flatCo();
  const A = E.deriveAssumptions(co);
  const p = E.projectPath(co, A, [], 12, null);
  // Monthly NI = (100k − 40k − 45k − 1k) × 0.75 = 10,500; OCF = NI + dep = 11,500 (no working-capital change)
  p.rows.forEach((r) => { close(r.netIncome, 10500, 1e-9); close(r.dWC, 0, 1e-6); close(r.ocf, 11500, 1e-9); });
  close(p.rows[11].cash, 50000 + 12 * 11500, 1e-9);
});

test('hiring adds fully-loaded salary cost and ramps revenue', () => {
  const co = flatCo();
  const A = E.deriveAssumptions(co);
  const d = E.newDecision('hire', { count: 2, salary: 60000, burden: 0.25, revPerHire: 5000, ramp: 2, start: 1 });
  const p = E.projectPath(co, A, [d], 3, null);
  close(p.rows[0].opex, 45000 + 12500);
  close(p.rows[0].revenue, 100000 + 2 * 5000 * 0.5); // half productivity in month 1
  close(p.rows[1].revenue, 110000);
});

test('loan: proceeds in funding month, amortizing payments afterwards', () => {
  const co = flatCo();
  const A = E.deriveAssumptions(co);
  const d = E.newDecision('loan', { amount: 120000, apr: 0.12, term: 12, start: 1 });
  const p = E.projectPath(co, A, [d], 13, null);
  const pay = E.pmt(0.01, 12, 120000);
  close(p.rows[0].proceeds, 120000); close(p.rows[0].interest, 0);
  close(p.rows[1].interest, 1200); close(p.rows[1].principal, pay - 1200);
  close(p.rows[12].debt, 0, 1e-6); // fully repaid after 12 payments
  const paid = p.rows.reduce((s, r) => s + r.interest + r.principal, 0);
  close(paid, pay * 12, 1e-6);
});

test('price change with elasticity moves revenue, volume and margin correctly', () => {
  const co = flatCo();
  const A = E.deriveAssumptions(co);
  const d = E.newDecision('price', { change: 0.10, elasticity: -1, start: 1 });
  const r = E.projectPath(co, A, [d], 1, null).rows[0];
  close(r.revenue, 100000 * 0.9 * 1.1); // 99,000
  close(r.cogs, 40000 * 0.9); // unit cost unchanged, 10% fewer units
  close(r.grossMarginPct, 1 - 36000 / 99000);
});

test('collections improvement releases cash through working capital', () => {
  const co = flatCo();
  const A = E.deriveAssumptions(co);
  const d = E.newDecision('workingCapital', { dso: -15, dio: 0, dpo: 0, discount: 0, start: 1 });
  const p = E.projectPath(co, A, [d], 3, null);
  // After full phase-in, receivables are 15 days lower: 100k × 15 / DPM of cash released in total
  close(p.rows.reduce((s, r) => s - r.dWC, 0), 100000 * 15 / E.DPM, 1e-9);
});

test('equipment purchase is capitalized and depreciated, not expensed', () => {
  const co = flatCo();
  const A = E.deriveAssumptions(co);
  const d = E.newDecision('equipment', { cost: 60000, life: 5, savings: 0, revLift: 0, start: 1 });
  const r = E.projectPath(co, A, [d], 1, null).rows[0];
  close(r.capex, 60000); close(r.dep, 1000 + 1000); // 60k / 60 months
  close(r.netIncome, (100000 - 40000 - 45000 - 2000) * 0.75);
});

test('Monte Carlo with zero volatility equals the expected path', () => {
  const co = flatCo();
  const A = E.deriveAssumptions(co);
  const mc = E.monteCarlo(co, A, [], { months: 6, paths: 50 });
  const exp = E.projectPath(co, A, [], 6, null);
  assert.equal(mc.probCashOut, 0);
  close(mc.band[5].p10, exp.rows[5].cash, 1e-9); close(mc.band[5].p90, exp.rows[5].cash, 1e-9);
});

test('Monte Carlo is reproducible and uses common random numbers', () => {
  const co = flatCo();
  co.history = co.history.map((m, i) => ({ ...m, revenue: 100000 * (1 + 0.05 * Math.sin(i * 1.7)), cogs: 40000 * (1 + 0.05 * Math.sin(i * 1.7)) }));
  const A = E.deriveAssumptions(co);
  const a = E.monteCarlo(co, A, [], { months: 12, paths: 300, seed: 42 });
  const b = E.monteCarlo(co, A, [], { months: 12, paths: 300, seed: 42 });
  assert.deepEqual(a.band, b.band);
  // a decision with no effect on random draws gives identical spread around a shifted centre
  const d = E.newDecision('oneOff', { amount: -10000, month: 1 });
  const c = E.monteCarlo(co, A, [d], { months: 12, paths: 300, seed: 42 });
  close(a.band[11].p90 - a.band[11].p10, c.band[11].p90 - c.band[11].p10, 0.02);
});

test('mean-preserving shocks: average simulated revenue ≈ expected revenue', () => {
  const co = flatCo();
  co.history = co.history.map((m, i) => ({ ...m, revenue: 100000 * Math.exp(0.06 * Math.sin(i * 2.3)), cogs: 40000 * Math.exp(0.06 * Math.sin(i * 2.3)) }));
  const A = E.deriveAssumptions(co);
  const exp = E.projectPath(co, A, [], 12, null);
  let tot = 0; const N = 2000;
  for (let i = 0; i < N; i++) tot += E.projectPath(co, A, [], 12, E.normalGen(1000 + i)).rows[11].revenue;
  close(tot / N, exp.rows[11].revenue, 0.03);
});

test('a plan that burns cash is flagged critical with a funding gap', () => {
  const co = flatCo();
  const sc = { name: 'Overreach', decisions: [E.newDecision('hire', { count: 10, salary: 80000, burden: 0.25, revPerHire: 0, ramp: 1, start: 1 })] };
  const r = E.runScenario(co, sc, { months: 12, paths: 100 });
  assert.ok(r.expected.cashOutMonth !== null);
  assert.ok(r.flags.some((f) => f.sev === 'critical' && /run out of cash|outside funding/.test(f.title)));
  assert.ok(r.endRatios.fundingGap > 0);
});

test('healthy flat business gets no warnings', () => {
  const r = E.runScenario(flatCo(), { name: 'Base', decisions: [] }, { months: 12, paths: 100 });
  assert.ok(r.flags.every((f) => f.sev === 'good'));
});

test('one-off expense spike is flagged once, not twice', () => {
  const co = flatCo();
  co.history = co.history.map((m, i) => ({ ...m, revenue: 100000 + i * 500, otherOpex: i === 6 ? 15000 : 5000 + (i % 3) * 100 }));
  const an = E.detectAnomalies(co.history);
  const other = an.filter((a) => a.key === 'otherOpex');
  assert.equal(other.length, 1);
  assert.equal(other[0].month, 'M7');
});

/* Decision Lab — user interface. All figures come from window.Engine; the AI only receives Engine outputs. */
(function () {
  'use strict';
  const E = window.Engine;
  const SAMPLES = window.SAMPLES;
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const cssVar = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();

  // ---------------- formatting ----------------
  const nf0 = new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 });
  const MINUS = '−';
  function money(v, compact = false) {
    if (v == null || !isFinite(v)) return '—';
    if (compact) return E.money(v);
    return (v < 0 ? MINUS : '') + '$' + nf0.format(Math.abs(Math.round(v)));
  }
  const pct = (v, d = 1) => (v == null || !isFinite(v) ? '—' : `${v < 0 ? MINUS : ''}${Math.abs(v * 100).toFixed(d)}%`);
  const times = (v) => (v == null || !isFinite(v) ? '—' : `${v < 0 ? MINUS : ''}${Math.abs(v).toFixed(2)}×`);
  const days = (v) => (v == null || !isFinite(v) ? '—' : `${v.toFixed(0)} days`);
  const roeFmt = (v) => (v == null ? 'n/a (negative equity)' : Math.abs(v) > 2 ? 'Not meaningful (very small equity)' : pct(v));
  const months = (v) => (v == null ? 'Cash-generating' : `${v.toFixed(1)} months`);

  // ---------------- status helpers ----------------
  const STATUS = {
    good: { ic: '✓', label: 'Healthy' }, warning: { ic: '!', label: 'Watch' }, serious: { ic: '!!', label: 'Concern' }, critical: { ic: '✕', label: 'Critical' }, info: { ic: 'i', label: '' },
  };
  function statusChip(sev, label) {
    if (!sev || sev === 'info') return '';
    const s = STATUS[sev];
    return `<span class="status ${sev}"><span class="ic" aria-hidden="true">${s.ic}</span>${esc(label || s.label)}</span>`;
  }
  function riskLevel(p) {
    if (p < 0.03) return { sev: 'good', label: 'Low risk' };
    if (p < 0.10) return { sev: 'warning', label: 'Some risk' };
    if (p < 0.25) return { sev: 'serious', label: 'High risk' };
    return { sev: 'critical', label: 'Very high risk' };
  }

  // ---------------- state ----------------
  const STORE_KEY = 'decision-lab.v1';
  const SC_COLORS = ['--series-base', '--series-a', '--series-b'];
  const SC_TAGS = ['Current course', 'Option A', 'Option B'];
  let store = {};
  try { store = JSON.parse(localStorage.getItem(STORE_KEY) || '{}') || {}; } catch (e) { store = {}; }
  const state = {
    companyId: store.companyId || SAMPLES[0].id,
    company: null, scenarios: null,
    settings: Object.assign({ months: 24, volMult: 1, paths: 1000 }, store.settings || {}),
    ui: { fan: 1, detail: 1 },
    today: null, results: null, error: null,
  };

  function scenariosFromSample(s) {
    return [
      { id: 'base', name: 'Keep current course', decisions: [] },
      ...[0, 1].map((i) => {
        const def = s.scenarios && s.scenarios[i];
        return { id: i ? 'b' : 'a', name: def ? def.name : `Option ${i ? 'B' : 'A'}`, decisions: def ? def.decisions.map(([t, p]) => E.newDecision(t, p)) : [] };
      }),
    ];
  }
  function blankCompany() {
    const months = ['Nov 2025', 'Dec 2025', 'Jan 2026', 'Feb 2026', 'Mar 2026', 'Apr 2026', 'May 2026', 'Jun 2026', 'Jul 2026', 'Aug 2026', 'Sep 2026', 'Oct 2026'];
    return {
      id: 'custom', name: 'My business', tagline: 'Your own figures', industry: 'Your industry', question: 'What decision are you weighing?',
      history: months.map((m) => ({ month: m, revenue: 50000, cogs: 22000, payroll: 15000, rent: 4000, otherOpex: 6000 })),
      balance: { cash: 40000, ar: 12000, inventory: 15000, otherCurrentAssets: 0, fixedAssets: 60000, otherAssets: 0, ap: 9000, accrued: 3000, debt: 0, debtApr: 0.08, debtPayment: 0 },
      taxRate: 0.25, depreciation: 800, capex: 0, costInflation: 0.03, overrides: {}, scenarios: [],
    };
  }
  function loadCompany(id) {
    const saved = store.companies && store.companies[id];
    const sample = SAMPLES.find((s) => s.id === id);
    if (saved) { state.company = saved.company; state.scenarios = saved.scenarios; }
    else if (sample) { state.company = clone(sample); state.company.overrides = {}; state.scenarios = scenariosFromSample(sample); }
    else { state.company = blankCompany(); state.scenarios = scenariosFromSample(state.company); }
    state.companyId = id;
  }
  let saveTimer = null;
  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      try {
        store.companyId = state.companyId; store.settings = state.settings;
        store.companies = store.companies || {};
        store.companies[state.companyId] = { company: state.company, scenarios: state.scenarios };
        localStorage.setItem(STORE_KEY, JSON.stringify(store));
      } catch (e) { /* storage unavailable: fine */ }
    }, 300);
  }

  // ---------------- month labels ----------------
  const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function futureLabel(t) {
    const h = state.company.history;
    const m = /^([A-Za-z]{3})\w* (\d{4})$/.exec(h[h.length - 1].month || '');
    if (!m || MON.indexOf(m[1].slice(0, 1).toUpperCase() + m[1].slice(1, 3).toLowerCase()) < 0) return `Month ${t}`;
    const mi = MON.indexOf(m[1].slice(0, 1).toUpperCase() + m[1].slice(1, 3).toLowerCase());
    const idx = mi + t;
    return `${MON[idx % 12]} ${+m[2] + Math.floor(idx / 12)}`;
  }

  // ---------------- compute ----------------
  let recomputeTimer = null;
  function scheduleRecompute() { clearTimeout(recomputeTimer); recomputeTimer = setTimeout(recompute, 120); }
  function recompute() {
    const opts = { months: state.settings.months, paths: state.settings.paths, volMult: state.settings.volMult };
    try {
      validateCompany(state.company);
      state.today = E.analyzeToday(state.company);
      state.results = state.scenarios.map((sc) => E.runScenario(state.company, sc, opts));
      state.error = null;
    } catch (e) {
      state.error = e.message || String(e);
    }
    renderResults();
    save();
  }
  function validateCompany(c) {
    if (!c.history || c.history.length < 3) throw new Error('Enter at least 3 months of history on the "Your data" tab.');
    c.history.forEach((m, i) => { if (!(m.revenue > 0)) throw new Error(`Revenue must be above zero (row ${i + 1}, ${m.month || 'unnamed month'}).`); });
  }

  // ---------------- charts ----------------
  let charts = {};
  function chartDefaults() {
    Chart.defaults.font.family = cssVar('--font') || 'system-ui';
    Chart.defaults.font.size = 11.5;
    Chart.defaults.color = cssVar('--muted');
    Chart.defaults.borderColor = cssVar('--grid');
    Chart.defaults.animation = false;
    Chart.defaults.plugins.legend.display = false;
    Chart.defaults.plugins.tooltip.backgroundColor = cssVar('--ink');
    Chart.defaults.plugins.tooltip.titleColor = cssVar('--surface');
    Chart.defaults.plugins.tooltip.bodyColor = cssVar('--surface');
    Chart.defaults.plugins.tooltip.padding = 10;
    Chart.defaults.plugins.tooltip.boxPadding = 4;
    Chart.defaults.plugins.tooltip.usePointStyle = true;
    Chart.defaults.elements.point.radius = 0;
    Chart.defaults.elements.point.hoverRadius = 4;
    Chart.defaults.elements.line.borderWidth = 2;
    Chart.defaults.elements.line.tension = 0.2;
  }
  const zeroLine = {
    id: 'zeroLine',
    afterDatasetsDraw(chart) {
      const y = chart.scales.y; if (!y || y.min > 0 || y.max < 0) return;
      const py = y.getPixelForValue(0), { left, right } = chart.chartArea, c = chart.ctx;
      c.save(); c.strokeStyle = cssVar('--critical'); c.lineWidth = 1; c.beginPath(); c.moveTo(left, py); c.lineTo(right, py); c.stroke();
      c.fillStyle = cssVar('--critical-ink'); c.font = `600 11px ${cssVar('--font')}`; c.fillText('$0: out of cash', left + 6, py - 5); c.restore();
    },
  };
  const moneyAxis = (extra) => Object.assign({ grid: { color: cssVar('--grid') }, border: { display: false }, ticks: { callback: (v) => money(v, true), maxTicksLimit: 6 } }, extra || {});
  const xAxis = () => ({ grid: { display: false }, border: { color: cssVar('--axis') }, ticks: { maxRotation: 0, autoSkip: true, maxTicksLimit: 9 } });
  function hexA(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(hex); if (!m) return hex;
    const n = parseInt(m[1], 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`;
  }
  function makeChart(id, config) {
    if (charts[id]) { charts[id].destroy(); }
    charts[id] = new Chart(document.getElementById(id), config);
    return charts[id];
  }
  function legendHTML(items) {
    return items.map((i) => `<span><i class="${i.band ? 'band' : ''}" style="--c:${i.color}"></i>${esc(i.label)}</span>`).join('');
  }
  function segHTML(selected, includeBase = true) {
    return state.scenarios.map((sc, i) => (!includeBase && i === 0 ? '' : `<button data-i="${i}" aria-pressed="${i === selected}"><span class="swatch" style="--c:var(${SC_COLORS[i]})"></span>${esc(i === 0 ? 'Current course' : SC_TAGS[i])}</button>`)).join('');
  }

  function renderFan() {
    const R = state.results, s = state.ui.fan, r = R[s];
    const labels = ['Now', ...Array.from({ length: state.settings.months }, (_, k) => futureLabel(k + 1))];
    const start = state.company.balance.cash;
    const col = cssVar(SC_COLORS[s]);
    const series = (k) => [start, ...r.mc.band.map((b) => b[k])];
    const ds = [
      { key: 'p90', data: series('p90'), borderWidth: 0, backgroundColor: hexA(col, 0.13), fill: '+1', pointHoverRadius: 0 },
      { key: 'p10', data: series('p10'), borderWidth: 0, fill: false, pointHoverRadius: 0 },
      { key: 'p75', data: series('p75'), borderWidth: 0, backgroundColor: hexA(col, 0.22), fill: '+1', pointHoverRadius: 0 },
      { key: 'p25', data: series('p25'), borderWidth: 0, fill: false, pointHoverRadius: 0 },
    ];
    R.forEach((rr, i) => {
      if (i === s) return;
      ds.push({ key: 'other', label: `${rr.scenario.name} (median)`, data: [start, ...rr.mc.band.map((b) => b.p50)], borderColor: cssVar(SC_COLORS[i]), borderWidth: 1.5, backgroundColor: cssVar(SC_COLORS[i]), fill: false });
    });
    ds.push({ key: 'p50', label: `${r.scenario.name} (median)`, data: series('p50'), borderColor: col, backgroundColor: col, borderWidth: 2.5, fill: false });
    $('#fanSeg').innerHTML = segHTML(s);
    $('#fanSub').textContent = `${r.scenario.name}: the line is the middle outcome of ${r.mc.paths.toLocaleString()} simulated futures. The darker band holds half of them; the lighter band holds 80%.`;
    $('#fanLegend').innerHTML = legendHTML([
      { label: `${r.scenario.name}: median`, color: col },
      { label: 'Middle 50% of futures', color: col, band: true },
      { label: 'Middle 80% of futures', color: hexA(col, 0.5), band: true },
      ...R.map((rr, i) => (i === s ? null : { label: `${rr.scenario.name} (median)`, color: cssVar(SC_COLORS[i]) })).filter(Boolean),
    ]);
    makeChart('fanChart', {
      type: 'line', data: { labels, datasets: ds }, plugins: [zeroLine],
      options: {
        maintainAspectRatio: false, interaction: { mode: 'index', intersect: false },
        scales: { x: xAxis(), y: moneyAxis() },
        plugins: { tooltip: {
          filter: (it) => ['p50', 'other', 'p90'].includes(it.dataset.key),
          itemSort: (a, b) => (a.dataset.key === 'p50' ? -1 : b.dataset.key === 'p50' ? 1 : 0),
          callbacks: { label: (it) => {
            if (it.dataset.key === 'p90') { const lo = ds[1].data[it.dataIndex]; return ` 80% range: ${money(lo, true)} to ${money(it.raw, true)}`; }
            return ` ${it.dataset.label}: ${money(it.raw)}`;
          } },
        } },
      },
    });
  }
  function renderRiskChart() {
    const R = state.results;
    const labels = Array.from({ length: state.settings.months }, (_, k) => futureLabel(k + 1));
    $('#riskLegend').innerHTML = legendHTML(R.map((r, i) => ({ label: r.scenario.name, color: cssVar(SC_COLORS[i]) })));
    makeChart('riskChart', {
      type: 'line',
      data: { labels, datasets: R.map((r, i) => ({ label: r.scenario.name, data: r.mc.probCashOutByMonth.map((p) => p * 100), borderColor: cssVar(SC_COLORS[i]), backgroundColor: cssVar(SC_COLORS[i]), fill: false, tension: 0, stepped: false })) },
      options: {
        maintainAspectRatio: false, interaction: { mode: 'index', intersect: false },
        scales: { x: xAxis(), y: { min: 0, max: 100, grid: { color: cssVar('--grid') }, border: { display: false }, ticks: { callback: (v) => v + '%', stepSize: 25 } } },
        plugins: { tooltip: { callbacks: { label: (it) => ` ${it.dataset.label}: ${it.raw.toFixed(1)}%` } } },
      },
    });
  }

  // ---------------- scenario builder ----------------
  function paramInput(d, p) {
    const v = d.params[p.key];
    const id = `p_${d.id}_${p.key}`;
    let input;
    if (p.type === 'month') {
      const opts = Array.from({ length: state.settings.months }, (_, k) => `<option value="${k + 1}" ${v === k + 1 ? 'selected' : ''}>Month ${k + 1} (${esc(futureLabel(k + 1))})</option>`).join('');
      input = `<select id="${id}" data-dec="${d.id}" data-key="${p.key}" data-type="month">${opts}</select>`;
    } else {
      const shown = p.type === 'pct' ? +(v * 100).toFixed(4) : v;
      const step = p.type === 'money' ? 1000 : p.type === 'pct' ? 0.5 : p.step || 1;
      const pre = p.type === 'money' ? '<span>$</span>' : '';
      const post = p.type === 'pct' ? '<span>%</span>' : '';
      input = `<div class="inwrap">${pre}<input id="${id}" type="number" step="${step}" value="${shown}" data-dec="${d.id}" data-key="${p.key}" data-type="${p.type}">${post}</div>`;
    }
    return `<div class="field"><label for="${id}">${esc(p.label)}</label>${input}${p.help ? `<span class="help">${esc(p.help)}</span>` : ''}</div>`;
  }
  function decisionCard(sc, d) {
    const def = E.DECISIONS[d.type];
    return `<div class="dec ${d.enabled === false ? 'off' : ''}" data-dec-card="${d.id}">
      <div class="dec-head" data-toggle="${d.id}" role="button" tabindex="0" aria-expanded="${!!d._open}">
        <input type="checkbox" data-enable="${d.id}" ${d.enabled === false ? '' : 'checked'} aria-label="Include this decision" title="Include this decision">
        <div class="txt"><div class="t">${esc(def.label)}</div><div class="s" data-summary="${d.id}">${esc(def.summary(d.params))}</div></div>
        <button class="btn small ghost" data-remove="${d.id}" aria-label="Remove decision" title="Remove">✕</button>
      </div>
      ${d._open ? `<div class="dec-body">${def.params.map((p) => paramInput(d, p)).join('')}</div>` : ''}
    </div>`;
  }
  function addDecisionSelect(sc) {
    const groups = {};
    for (const [k, def] of Object.entries(E.DECISIONS)) (groups[def.group] = groups[def.group] || []).push(`<option value="${k}">${esc(def.label)}</option>`);
    return `<div class="add-dec"><select data-add="${sc.id}" aria-label="Add a decision"><option value="">+ Add a decision…</option>${Object.entries(groups).map(([g, o]) => `<optgroup label="${esc(g)}">${o.join('')}</optgroup>`).join('')}</select></div>`;
  }
  function renderScenarioCols() {
    const A = state.today ? state.today.assumptions : null;
    $('#scenarioCols').innerHTML = state.scenarios.map((sc, i) => {
      const head = `<div class="tag"><span class="swatch"></span>${SC_TAGS[i]}</div>`;
      if (i === 0) {
        return `<div class="card scen" style="--c:var(${SC_COLORS[i]})">${head}
          <div class="name" style="padding:6px 0">${esc(sc.name)}</div>
          <p class="sub" style="margin:0">What happens if nothing changes: recent trends simply continue.</p>
          ${A ? `<table><tbody>
            <tr><td>Revenue trend</td><td class="n">${pct(A.growth, 2)} / month</td></tr>
            <tr><td>Gross margin</td><td class="n">${pct(A.grossMargin)}</td></tr>
            <tr><td>Fixed operating costs</td><td class="n">${money(A.fixedOpex)} / mo</td></tr>
            <tr><td>Starting cash</td><td class="n">${money(state.company.balance.cash)}</td></tr>
          </tbody></table><p class="small muted" style="margin:0">Adjust these on the <a href="#data" data-tab="data">Your data</a> tab.</p>` : ''}
        </div>`;
      }
      return `<div class="card scen" style="--c:var(${SC_COLORS[i]})">${head}
        <input class="name" type="text" value="${esc(sc.name)}" data-scname="${i}" aria-label="${SC_TAGS[i]} name">
        ${sc.decisions.length ? sc.decisions.map((d) => decisionCard(sc, d)).join('') : '<div class="empty-dec">No decisions yet. Add one below to see how it changes the outlook.</div>'}
        ${addDecisionSelect(sc)}
      </div>`;
    }).join('');
  }
  function findDecision(id) {
    for (const sc of state.scenarios) { const d = sc.decisions.find((x) => x.id === id); if (d) return { sc, d }; }
    return null;
  }
  function bindScenarioEvents() {
    const root = $('#scenarioCols');
    root.addEventListener('input', (e) => {
      const t = e.target;
      if (t.dataset.scname) { state.scenarios[+t.dataset.scname].name = t.value || SC_TAGS[+t.dataset.scname]; renderResults(); save(); return; }
      if (t.dataset.dec) {
        const f = findDecision(t.dataset.dec); if (!f) return;
        let v = parseFloat(t.value);
        if (!isFinite(v)) return;
        if (t.dataset.type === 'pct') v = v / 100;
        if (t.dataset.type === 'int' || t.dataset.type === 'month') v = Math.round(v);
        const p = E.DECISIONS[f.d.type].params.find((x) => x.key === t.dataset.key);
        if (p.min != null) v = Math.max(t.dataset.type === 'pct' ? p.min : p.min, v);
        if (p.max != null) v = Math.min(p.max, v);
        f.d.params[t.dataset.key] = v;
        const s = root.querySelector(`[data-summary="${f.d.id}"]`); if (s) s.textContent = E.DECISIONS[f.d.type].summary(f.d.params);
        scheduleRecompute();
      }
    });
    root.addEventListener('change', (e) => {
      const t = e.target;
      if (t.dataset.add) {
        if (!t.value) return;
        const sc = state.scenarios.find((s) => s.id === t.dataset.add);
        const d = E.newDecision(t.value); d._open = true;
        if (E.DECISIONS[t.value].params.some((p) => p.key === 'start')) d.params.start = Math.min(d.params.start, state.settings.months);
        sc.decisions.push(d);
        renderScenarioCols(); recompute();
      } else if (t.dataset.enable) {
        const f = findDecision(t.dataset.enable); f.d.enabled = t.checked;
        t.closest('.dec').classList.toggle('off', !t.checked); recompute();
      } else if (t.dataset.dec && t.dataset.type === 'month') {
        t.dispatchEvent(new Event('input', { bubbles: true }));
      }
    });
    root.addEventListener('click', (e) => {
      const rm = e.target.closest('[data-remove]');
      if (rm) {
        e.stopPropagation();
        const f = findDecision(rm.dataset.remove); f.sc.decisions = f.sc.decisions.filter((x) => x !== f.d);
        renderScenarioCols(); recompute(); return;
      }
      if (e.target.matches('input[type=checkbox]')) { e.stopPropagation(); return; }
      const tg = e.target.closest('[data-toggle]');
      if (tg) { const f = findDecision(tg.dataset.toggle); f.d._open = !f.d._open; renderScenarioCols(); save(); }
    });
    root.addEventListener('keydown', (e) => {
      const tg = e.target.closest('[data-toggle]');
      if (tg && e.target === tg && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); tg.click(); }
    });
  }

  // ---------------- lab results ----------------
  const COMPARE_ROWS = [
    { grp: 'Cash and risk' },
    { label: 'Chance of running out of cash', help: (m) => `Within ${m} months, across all simulated futures`, get: (r) => r.mc.probCashOut, fmt: (v) => pct(v, 1), better: 'lower', diff: (a, b) => `${((a - b) * 100 >= 0 ? '+' : MINUS)}${Math.abs((a - b) * 100).toFixed(1)} pts` },
    { label: 'Expected cash at end', help: () => 'If things go as the trend suggests', get: (r) => r.expected.rows[r.months - 1].cash, fmt: money, better: 'higher' },
    { label: 'Pessimistic cash at end', help: () => 'Only 1 in 10 simulated futures end lower', get: (r) => r.mc.endCash.p10, fmt: money, better: 'higher' },
    { label: 'Lowest expected cash', help: () => 'The tightest point along the way', get: (r) => r.expected.minCash, fmt: money, better: 'higher', extra: (r) => (r.expected.minCashMonth ? `in ${futureLabel(r.expected.minCashMonth)}` : 'today') },
    { label: 'Outside funding needed', help: () => 'Cash shortfall at the lowest point (expected path)', get: (r) => Math.max(0, -r.expected.minCash), fmt: money, better: 'lower' },
    { grp: 'Profit' },
    { label: 'Total revenue', help: (m) => `Over ${m} months`, get: (r) => r.totals.revenue, fmt: money, better: 'higher' },
    { label: 'Total net income', help: (m) => `Profit after interest and tax, over ${m} months`, get: (r) => r.totals.netIncome, fmt: money, better: 'higher' },
    { label: 'Total free cash flow', help: () => 'Operating cash flow minus investment spending', get: (r) => r.totals.fcf, fmt: money, better: 'higher' },
    { label: 'Net margin at end', help: () => 'Net income ÷ revenue, last 3 months', get: (r) => r.endRatios.netMargin, fmt: (v) => pct(v), better: 'higher', diff: (a, b) => `${a - b >= 0 ? '+' : MINUS}${Math.abs((a - b) * 100).toFixed(1)} pts` },
    { grp: 'Balance sheet strength (end of period)' },
    { label: 'Debt service coverage (DSCR)', help: () => 'Worst 12-month EBITDA ÷ loan payments. Banks look for 1.25× or more', get: (r) => r.worstDSCR, fmt: times, better: 'higher' },
    { label: 'Current ratio', help: () => 'Short-term assets ÷ short-term obligations', get: (r) => r.endRatios.currentRatio, fmt: times, better: 'higher' },
    { label: 'Debt-to-equity', help: () => 'Total debt ÷ owner equity', get: (r) => r.endRatios.debtToEquity, fmt: (v) => (v == null ? 'Negative equity' : times(v)), better: 'lower' },
    { label: 'Return on equity (annualized)', help: () => 'Net income ÷ owner equity', get: (r) => r.endRatios.roe, fmt: roeFmt, better: 'higher', diff: (a, b) => `${a - b >= 0 ? '+' : MINUS}${Math.abs((a - b) * 100).toFixed(1)} pts` },
  ];
  function deltaHTML(row, v, base) {
    if (v == null || base == null || !isFinite(v) || !isFinite(base)) return '';
    if (row.fmt === roeFmt && (Math.abs(v) > 2 || Math.abs(base) > 2)) return '';
    const d = v - base;
    if (Math.abs(d) < 1e-9 || (Math.abs(d) < 0.5 && row.fmt === money)) return '<span class="delta same">no change</span>';
    const good = row.better === 'higher' ? d > 0 : d < 0;
    const txt = row.diff ? row.diff(v, base) : (row.fmt === money ? `${d >= 0 ? '+' : MINUS}${money(Math.abs(d))}` : `${d >= 0 ? '+' : MINUS}${row.fmt(Math.abs(d))}`);
    return `<span class="delta ${good ? 'better' : 'worse'}">${d > 0 ? '▲' : '▼'} ${txt} <span class="sr">${good ? 'better' : 'worse'}</span></span>`;
  }
  function renderCompare() {
    const R = state.results, m = state.settings.months;
    let html = `<thead><tr><th>Measure</th>${R.map((r, i) => `<th class="n"><span class="row" style="justify-content:flex-end;gap:6px"><span class="swatch" style="--c:var(${SC_COLORS[i]})"></span>${esc(r.scenario.name)}</span></th>`).join('')}</tr></thead><tbody>`;
    for (const row of COMPARE_ROWS) {
      if (row.grp) { html += `<tr class="grp"><td colspan="${R.length + 1}">${esc(row.grp)}</td></tr>`; continue; }
      const base = row.get(R[0]);
      html += `<tr><td><div class="metric-name">${esc(row.label)}</div><div class="metric-help">${esc(row.help(m))}</div></td>${R.map((r, i) => {
        const v = row.get(r);
        return `<td class="n">${row.fmt(v)}${row.extra ? `<span class="delta same">${esc(row.extra(r))}</span>` : ''}${i ? deltaHTML(row, v, base) : ''}</td>`;
      }).join('')}</tr>`;
    }
    $('#compareTbl').innerHTML = html + '</tbody>';
  }
  function renderVerdicts() {
    const m = state.settings.months;
    $('#verdicts').innerHTML = state.results.map((r, i) => {
      const lv = riskLevel(r.mc.probCashOut);
      const endExp = r.expected.rows[m - 1].cash;
      return `<div class="card verdict" style="--c:var(${SC_COLORS[i]})">
        <div class="row"><span class="swatch"></span><b>${esc(r.scenario.name)}</b><span class="spacer"></span>${statusChip(lv.sev, lv.label)}</div>
        <div style="margin:8px 0 10px"><div class="big num">${pct(r.mc.probCashOut, r.mc.probCashOut < 0.1 && r.mc.probCashOut > 0 ? 1 : 0)}</div><div class="lbl">chance of running out of cash within ${m} months</div></div>
        <div class="kv"><span>Expected cash in ${esc(futureLabel(m))}</span><b class="num">${money(endExp, true)}</b></div>
        <div class="kv"><span>80% of futures end between</span><b class="num">${money(r.mc.band[m - 1].p10, true)} and ${money(r.mc.band[m - 1].p90, true)}</b></div>
        <div class="kv"><span>Total net income</span><b class="num">${money(r.totals.netIncome, true)}</b></div>
      </div>`;
    }).join('');
  }
  function flagList(flags) {
    return flags.map((f) => `<li>${statusChip(f.sev, f.title)}<p>${esc(f.detail)}</p></li>`).join('');
  }
  function renderFlagCols() {
    $('#flagCols').innerHTML = state.results.map((r, i) => `<div class="card" style="border-top:4px solid var(${SC_COLORS[i]})">
      <div class="row"><h3 style="margin:0">Warning signs: ${esc(r.scenario.name)}</h3></div>
      <p class="sub" style="margin:4px 0 10px">Rule-based checks on the projection</p>
      <ul class="flags">${flagList(r.flags)}</ul></div>`).join('');
  }

  // ---------------- today ----------------
  const METRICS = [
    { grp: 'Profitability' },
    { key: 'grossMargin', label: 'Gross margin', fmt: (v) => pct(v), formula: '(Revenue − COGS) ÷ Revenue', meaning: 'Share of each sales dollar left after direct costs.', assess: () => null },
    { key: 'operatingMargin', label: 'Operating margin', fmt: (v) => pct(v), formula: 'Operating profit (EBIT) ÷ Revenue', meaning: 'Profit from running the business, before interest and tax.', assess: (v) => (v < 0 ? 'serious' : v < 0.05 ? 'warning' : 'good') },
    { key: 'netMargin', label: 'Net profit margin', fmt: (v) => pct(v), formula: 'Net income ÷ Revenue', meaning: 'Cents of profit kept from each sales dollar.', assess: (v) => (v < 0 ? 'serious' : v < 0.05 ? 'warning' : 'good') },
    { key: 'roa', label: 'Return on assets (ROA)', fmt: (v) => pct(v), formula: 'Net income ÷ Total assets', meaning: 'How productively the business uses what it owns.', assess: (v) => (v < 0 ? 'serious' : v < 0.05 ? 'warning' : 'good') },
    { key: 'roe', label: 'Return on equity (ROE)', fmt: roeFmt, formula: 'Net income ÷ Owner equity', meaning: 'Return earned on the owners’ stake.', assess: (v) => (v == null ? 'critical' : v < 0 ? 'serious' : v < 0.1 ? 'warning' : 'good') },
    { grp: 'Liquidity' },
    { key: 'currentRatio', label: 'Current ratio', fmt: times, formula: 'Current assets ÷ Current liabilities', meaning: 'Can short-term assets pay bills due within a year?', assess: (v) => (v < 1 ? 'serious' : v < 1.5 ? 'warning' : 'good') },
    { key: 'quickRatio', label: 'Quick ratio', fmt: times, formula: '(Cash + Receivables) ÷ Current liabilities', meaning: 'Same test, without counting inventory.', assess: (v) => (v < 0.5 ? 'serious' : v < 1 ? 'warning' : 'good') },
    { key: 'cashRatio', label: 'Cash ratio', fmt: times, formula: 'Cash ÷ Current liabilities', meaning: 'Bills you could pay today with cash alone.', assess: () => null },
    { grp: 'Leverage and solvency' },
    { key: 'debtToEquity', label: 'Debt-to-equity', fmt: (v) => (v == null ? 'n/a (negative equity)' : times(v)), formula: 'Total debt ÷ Owner equity', meaning: 'How much the business relies on borrowed money.', assess: (v) => (v == null ? 'critical' : v > 3 ? 'serious' : v > 2 ? 'warning' : 'good') },
    { key: 'debtToAssets', label: 'Debt-to-assets', fmt: (v) => pct(v), formula: 'Total debt ÷ Total assets', meaning: 'Share of assets financed by loans.', assess: (v) => (v > 0.6 ? 'serious' : v > 0.4 ? 'warning' : 'good') },
    { key: 'interestCoverage', label: 'Interest coverage', fmt: (v) => (v == null ? 'No debt' : times(v)), formula: 'EBIT ÷ Interest expense', meaning: 'How many times operating profit covers interest.', assess: (v) => (v == null ? 'good' : v < 1.5 ? 'serious' : v < 3 ? 'warning' : 'good') },
    { key: 'dscr', label: 'Debt service coverage (DSCR)', fmt: (v) => (v == null ? 'No debt' : times(v)), formula: 'EBITDA ÷ (Interest + Principal payments)', meaning: 'Can operating earnings cover loan payments? Banks want 1.25×+.', assess: (v) => (v == null ? 'good' : v < 1 ? 'critical' : v < 1.25 ? 'serious' : v < 1.5 ? 'warning' : 'good') },
    { grp: 'Efficiency (working capital)' },
    { key: 'dso', label: 'Days sales outstanding', fmt: days, formula: 'Receivables ÷ Monthly revenue × 30.4', meaning: 'How long customers take to pay you.', assess: (v) => (v > 60 ? 'warning' : 'good') },
    { key: 'dio', label: 'Days inventory on hand', fmt: (v) => (v ? days(v) : 'No inventory'), formula: 'Inventory ÷ Monthly COGS × 30.4', meaning: 'How long stock sits before it is sold.', assess: (v) => (v > 90 ? 'warning' : v ? 'good' : null) },
    { key: 'dpo', label: 'Days payables outstanding', fmt: days, formula: 'Payables ÷ Monthly COGS × 30.4', meaning: 'How long you take to pay suppliers.', assess: () => null },
    { key: 'cashConversionCycle', label: 'Cash conversion cycle', fmt: days, formula: 'DSO + DIO − DPO', meaning: 'Days cash is tied up between paying suppliers and getting paid.', assess: () => null },
    { grp: 'Cash' },
    { key: 'runwayMonths', label: 'Cash runway', fmt: months, formula: 'Cash ÷ Average monthly cash burn', meaning: 'Months until cash runs out at the recent pace.', assess: (v) => (v == null ? 'good' : v < 6 ? 'critical' : v < 12 ? 'serious' : v < 18 ? 'warning' : 'good') },
  ];
  function renderToday() {
    const T = state.today, r = T.ratios, c = state.company;
    const tiles = [
      { k: `Revenue (last ${T.months} mo)`, v: money(T.flows.revenue, true), d: `${T.trend.revenueChange >= 0 ? '▲' : '▼'} ${pct(Math.abs(T.trend.revenueChange))} first 3 vs last 3 months` },
      { k: 'Net income', v: money(T.flows.netIncome, true), d: `Net margin ${pct(r.netMargin)}`, sev: r.netMargin < 0 ? 'serious' : r.netMargin < 0.05 ? 'warning' : 'good' },
      { k: 'Cash today', v: money(c.balance.cash, true), d: r.runwayMonths == null ? 'Business is generating cash' : `Runway ≈ ${r.runwayMonths.toFixed(1)} months`, sev: METRICS.find((x) => x.key === 'runwayMonths').assess(r.runwayMonths) },
      { k: 'Current ratio', v: times(r.currentRatio), d: 'Short-term assets ÷ obligations', sev: METRICS.find((x) => x.key === 'currentRatio').assess(r.currentRatio) },
      { k: 'Debt-to-equity', v: r.debtToEquity == null ? 'Negative' : times(r.debtToEquity), d: `Debt ${money(r.debt, true)}`, sev: METRICS.find((x) => x.key === 'debtToEquity').assess(r.debtToEquity) },
      { k: 'Debt service coverage', v: r.dscr == null ? 'No debt' : times(r.dscr), d: 'Lenders look for 1.25× or more', sev: METRICS.find((x) => x.key === 'dscr').assess(r.dscr) },
      { k: 'Return on equity', v: r.roe == null ? 'n/a' : pct(r.roe), d: `ROA ${pct(r.roa)}`, sev: METRICS.find((x) => x.key === 'roe').assess(r.roe) },
      { k: 'Cash conversion cycle', v: days(r.cashConversionCycle), d: `Collect ${days(r.dso)} · stock ${days(r.dio)} · pay ${days(r.dpo)}` },
    ];
    $('#todayTiles').innerHTML = tiles.map((t) => `<div class="card tile"><div class="k"><span>${esc(t.k)}</span>${t.sev ? statusChip(t.sev, '') : ''}</div><div class="v">${esc(t.v)}</div><div class="d">${esc(t.d)}</div></div>`).join('');
    $('#ratioSub').textContent = `Income figures cover the last ${T.months} months of history; balance sheet figures are as of today. Interest is estimated from today's loan balance.`;
    $('#ratioTbl').innerHTML = `<thead><tr><th>Ratio</th><th class="n">Value</th><th>Assessment</th></tr></thead><tbody>${METRICS.map((m) => {
      if (m.grp) return `<tr class="grp"><td colspan="3">${esc(m.grp)}</td></tr>`;
      const v = r[m.key];
      const sev = v === undefined ? null : m.assess(v);
      return `<tr><td><div class="metric-name">${esc(m.label)}</div><div class="metric-help">${esc(m.meaning)} <span title="Formula">· ${esc(m.formula)}</span></div></td><td class="n">${esc(m.fmt(v))}</td><td>${statusChip(sev)}</td></tr>`;
    }).join('')}</tbody>`;
    $('#todayFlags').innerHTML = flagList(E.todayFlags(T));
    // charts
    const labels = T.series.map((s) => s.month);
    $('#histLegend').innerHTML = legendHTML([{ label: 'Revenue', color: cssVar('--series-a') }, { label: 'Operating profit (before depreciation)', color: cssVar('--series-b') }]);
    makeChart('histChart', {
      type: 'bar',
      data: { labels, datasets: [
        { type: 'bar', label: 'Revenue', data: T.series.map((s) => s.revenue), backgroundColor: cssVar('--series-a'), borderRadius: 4, maxBarThickness: 26, order: 2 },
        { type: 'line', label: 'Operating profit', data: T.series.map((s) => s.operatingProfit), borderColor: cssVar('--series-b'), backgroundColor: cssVar('--series-b'), pointRadius: 3, order: 1 },
      ] },
      options: { maintainAspectRatio: false, interaction: { mode: 'index', intersect: false }, scales: { x: xAxis(), y: moneyAxis() }, plugins: { tooltip: { callbacks: { label: (it) => ` ${it.dataset.label}: ${money(it.raw)}` } } } },
    });
    makeChart('gmChart', {
      type: 'line',
      data: { labels, datasets: [{ label: 'Gross margin', data: T.series.map((s) => s.grossMargin * 100), borderColor: cssVar('--series-a'), backgroundColor: cssVar('--series-a'), pointRadius: 3 }] },
      options: { maintainAspectRatio: false, interaction: { mode: 'index', intersect: false }, scales: { x: xAxis(), y: { grid: { color: cssVar('--grid') }, border: { display: false }, ticks: { callback: (v) => +v.toFixed(1) + '%', maxTicksLimit: 6 } } }, plugins: { tooltip: { callbacks: { label: (it) => ` Gross margin: ${it.raw.toFixed(1)}%` } } } },
    });
  }

  // ---------------- detail ----------------
  const DETAIL_ROWS = [
    ['Income statement'], ['revenue', 'Revenue'], ['cogs', 'Cost of goods sold', -1], ['grossProfit', 'Gross profit', 0, true], ['opex', 'Operating expenses', -1], ['oneTime', 'One-time items', -1],
    ['ebitda', 'EBITDA', 0, true], ['dep', 'Depreciation', -1], ['interest', 'Interest', -1], ['tax', 'Tax', -1], ['netIncome', 'Net income', 0, true],
    ['Cash flow'], ['dWC', 'Cash tied up in working capital', -1], ['ocf', 'Operating cash flow', 0, true], ['capex', 'Investment (capex)', -1], ['proceeds', 'New borrowing'], ['principal', 'Loan principal repaid', -1], ['netCash', 'Net change in cash', 0, true],
    ['Balance'], ['cash', 'Cash at month end', 0, true], ['debt', 'Debt outstanding'], ['ar', 'Receivables'], ['inventory', 'Inventory'],
  ];
  function renderDetail() {
    const s = state.ui.detail, r = state.results[s], base = state.results[0], m = state.settings.months;
    $('#detailSeg').innerHTML = segHTML(s);
    const labels = Array.from({ length: m }, (_, k) => futureLabel(k + 1));
    const col = cssVar(SC_COLORS[s]);
    const items = [{ label: `${r.scenario.name}: net income`, color: col }];
    const ds = [{ type: 'bar', label: `${r.scenario.name}: net income`, data: r.expected.rows.map((x) => x.netIncome), backgroundColor: col, borderRadius: 4, maxBarThickness: 18, order: 2 }];
    if (s !== 0) { ds.push({ type: 'line', label: 'Current course: net income', data: base.expected.rows.map((x) => x.netIncome), borderColor: cssVar('--series-base'), backgroundColor: cssVar('--series-base'), order: 1 }); items.push({ label: 'Current course: net income', color: cssVar('--series-base') }); }
    $('#detailLegend').innerHTML = legendHTML(items);
    makeChart('detailChart', { type: 'bar', data: { labels, datasets: ds }, plugins: [zeroLine], options: { maintainAspectRatio: false, interaction: { mode: 'index', intersect: false }, scales: { x: xAxis(), y: moneyAxis() }, plugins: { tooltip: { callbacks: { label: (it) => ` ${it.dataset.label}: ${money(it.raw)}` } } } } });
    let html = `<thead><tr><th>${esc(r.scenario.name)}</th>${labels.map((l) => `<th class="n">${esc(l)}</th>`).join('')}<th class="n">Total</th></tr></thead><tbody>`;
    for (const [k, label, sign, bold] of DETAIL_ROWS) {
      if (!label) { html += `<tr class="grp"><td colspan="${m + 2}">${esc(k)}</td></tr>`; continue; }
      const vals = r.expected.rows.map((x) => (sign === -1 ? -x[k] : x[k]));
      const isStock = ['cash', 'debt', 'ar', 'inventory'].includes(k);
      const total = isStock ? null : vals.reduce((a, b) => a + b, 0);
      if (k === 'oneTime' && vals.every((v) => Math.abs(v) < 0.5)) continue;
      if (k === 'proceeds' && vals.every((v) => Math.abs(v) < 0.5)) continue;
      html += `<tr${bold ? ' style="font-weight:600"' : ''}><td>${esc(label)}</td>${vals.map((v) => `<td class="n">${money(v)}</td>`).join('')}<td class="n">${total == null ? '' : money(total)}</td></tr>`;
    }
    $('#detailTbl').innerHTML = html + '</tbody>';
    // ratios today vs end
    const keys = ['grossMargin', 'netMargin', 'roa', 'roe', 'currentRatio', 'quickRatio', 'debtToEquity', 'interestCoverage', 'dso', 'dio', 'cashConversionCycle'];
    const T = state.today.ratios;
    $('#ratioCompareTbl').innerHTML = `<thead><tr><th>Ratio</th><th class="n">Today</th>${state.results.map((rr, i) => `<th class="n"><span class="row" style="justify-content:flex-end;gap:6px"><span class="swatch" style="--c:var(${SC_COLORS[i]})"></span>${esc(rr.scenario.name)}</span></th>`).join('')}</tr></thead><tbody>${keys.map((k) => {
      const M = METRICS.find((x) => x.key === k);
      return `<tr><td><div class="metric-name">${esc(M.label)}</div><div class="metric-help">${esc(M.formula)}</div></td><td class="n">${esc(M.fmt(T[k]))}</td>${state.results.map((rr) => `<td class="n">${esc(M.fmt(rr.endRatios[k]))}</td>`).join('')}</tr>`;
    }).join('')}</tbody>`;
  }

  // ---------------- data editing ----------------
  const HIST_COLS = [['month', 'Month', 'text'], ['revenue', 'Revenue'], ['cogs', 'COGS'], ['payroll', 'Payroll'], ['rent', 'Rent'], ['otherOpex', 'Other operating expenses']];
  const BS_FIELDS = [
    ['cash', 'Cash in bank'], ['ar', 'Accounts receivable (owed to you)'], ['inventory', 'Inventory'], ['otherCurrentAssets', 'Other current assets'],
    ['fixedAssets', 'Equipment & property (net)'], ['otherAssets', 'Other long-term assets'], ['ap', 'Accounts payable (you owe suppliers)'], ['accrued', 'Other short-term liabilities'],
    ['debt', 'Loans outstanding'], ['debtApr', 'Loan interest rate (APR)', 'pct'], ['debtPayment', 'Monthly loan payment'],
  ];
  const OTHER_FIELDS = [['taxRate', 'Tax rate on profits', 'pct'], ['depreciation', 'Monthly depreciation'], ['capex', 'Routine monthly capital spending'], ['costInflation', 'Annual cost inflation', 'pct']];
  const ASSUMP_FIELDS = [
    ['startRevenue', 'Starting monthly revenue (trend)', 'money'], ['growth', 'Revenue trend growth per month', 'pct'], ['revVol', 'Typical monthly swing around trend', 'pct'],
    ['grossMargin', 'Gross margin', 'pct'], ['fixedOpex', 'Monthly operating expenses', 'money'], ['dso', 'Days to collect from customers', 'days'], ['dio', 'Days of inventory', 'days'], ['dpo', 'Days to pay suppliers', 'days'],
  ];
  function numField(id, label, value, kind, placeholder) {
    const shown = value == null || value === '' ? '' : kind === 'pct' ? +(value * 100).toFixed(3) : +(+value).toFixed(kind === 'days' ? 1 : 2);
    const ph = placeholder == null ? '' : kind === 'pct' ? (placeholder * 100).toFixed(2) : kind === 'days' ? placeholder.toFixed(1) : Math.round(placeholder);
    return `<div class="field"><label for="${id}">${esc(label)}</label><div class="inwrap">${kind === 'pct' || kind === 'days' ? '' : '<span>$</span>'}<input type="number" id="${id}" value="${shown}" placeholder="${ph}" step="any">${kind === 'pct' ? '<span>%</span>' : kind === 'days' ? '<span>days</span>' : ''}</div></div>`;
  }
  function renderData() {
    const c = state.company;
    $('#dataTitle').textContent = `${c.name}: ${c.tagline || ''}`;
    $('#histTbl').innerHTML = `<thead><tr>${HIST_COLS.map(([, l]) => `<th class="${l === 'Month' ? '' : 'n'}">${l}</th>`).join('')}<th class="n">Gross margin</th></tr></thead><tbody>${c.history.map((m, i) => `<tr>${HIST_COLS.map(([k, , t]) => `<td><input ${t === 'text' ? 'type="text"' : 'type="number" step="any"'} data-h="${i}" data-k="${k}" value="${esc(m[k])}" aria-label="${k} ${esc(m.month)}"></td>`).join('')}<td class="n" data-gm="${i}">${pct(m.revenue ? 1 - m.cogs / m.revenue : null)}</td></tr>`).join('')}</tbody>`;
    $('#bsForm').innerHTML = BS_FIELDS.map(([k, l, t]) => numField(`bs_${k}`, l, c.balance[k], t || 'money')).join('');
    $('#otherForm').innerHTML = OTHER_FIELDS.map(([k, l, t]) => numField(`ot_${k}`, l, c[k], t || 'money')).join('');
    renderAssumpForm();
    renderBsCheck();
  }
  function renderAssumpForm() {
    const c = state.company;
    let derived = null;
    try { derived = E.deriveAssumptions(Object.assign({}, c, { overrides: {} })); } catch (e) { /* ignore */ }
    $('#assumpForm').innerHTML = ASSUMP_FIELDS.map(([k, l, t]) => numField(`as_${k}`, `${l}${derived ? ` (calculated: ${t === 'pct' ? pct(derived[k], 2) : t === 'days' ? days(derived[k]) : money(derived[k])})` : ''}`, c.overrides && c.overrides[k] != null ? c.overrides[k] : '', t, derived ? derived[k] : null)).join('');
  }
  function renderBsCheck() {
    const b = state.company.balance;
    const assets = b.cash + b.ar + b.inventory + b.otherCurrentAssets + b.fixedAssets + b.otherAssets;
    const liab = b.ap + b.accrued + b.debt;
    $('#bsCheck').innerHTML = `Total assets <b>${money(assets)}</b> · total liabilities <b>${money(liab)}</b> · equity (assets − liabilities) <b>${money(assets - liab)}</b> ${assets - liab <= 0 ? statusChip('critical', 'Negative equity') : ''}`;
  }
  function bindData() {
    const view = $('#view-data');
    view.addEventListener('input', (e) => {
      const t = e.target, c = state.company;
      if (t.dataset.h != null) {
        const row = c.history[+t.dataset.h], k = t.dataset.k;
        if (k === 'month') row.month = t.value; else row[k] = parseFloat(t.value) || 0;
        const gm = view.querySelector(`[data-gm="${t.dataset.h}"]`); if (gm) gm.textContent = pct(row.revenue ? 1 - row.cogs / row.revenue : null);
        scheduleRecompute(); return;
      }
      const m = /^(bs|ot|as)_(\w+)$/.exec(t.id || ''); if (!m) return;
      const kind = (m[1] === 'bs' ? BS_FIELDS : m[1] === 'ot' ? OTHER_FIELDS : ASSUMP_FIELDS).find((f) => f[0] === m[2])[2] || 'money';
      let v = t.value === '' ? null : parseFloat(t.value);
      if (v != null && !isFinite(v)) return;
      if (v != null && kind === 'pct') v = v / 100;
      if (m[1] === 'bs') { c.balance[m[2]] = v || 0; renderBsCheck(); }
      else if (m[1] === 'ot') c[m[2]] = v || 0;
      else { c.overrides = c.overrides || {}; if (v == null) delete c.overrides[m[2]]; else c.overrides[m[2]] = v; }
      scheduleRecompute();
    });
    view.addEventListener('change', (e) => { if (e.target.dataset.h != null || /^(bs|ot)_/.test(e.target.id)) renderAssumpForm(); });
    $('#addMonthBtn').onclick = () => {
      const h = state.company.history, last = h[h.length - 1];
      const nm = (() => { const lbl = futureLabel(1); return lbl.startsWith('Month') ? `Month ${h.length + 1}` : lbl; })();
      h.push(Object.assign({}, last, { month: nm })); renderData(); recompute();
    };
    $('#delMonthBtn').onclick = () => { if (state.company.history.length <= 3) return toast('At least 3 months are needed.'); state.company.history.pop(); renderData(); recompute(); };
    $('#resetBtn').onclick = () => {
      if (store.companies) delete store.companies[state.companyId];
      const sample = SAMPLES.find((s) => s.id === state.companyId);
      if (!sample) { state.company = blankCompany(); state.scenarios = scenariosFromSample(state.company); } else loadCompany(state.companyId);
      fullRender(); toast('Restored the original data.');
    };
    $('#blankBtn').onclick = () => {
      state.companyId = 'custom';
      if (store.companies) delete store.companies.custom;
      loadCompany('custom'); renderCompanySel(); fullRender(); toast('Started a blank template: replace the numbers with your own.');
    };
    $('#csvFile').onchange = (e) => { const f = e.target.files[0]; if (!f) return; const rd = new FileReader(); rd.onload = () => { $('#csvIn').value = rd.result; }; rd.readAsText(f); };
    $('#importBtn').onclick = () => {
      try {
        const rows = parseCSV($('#csvIn').value);
        if (rows.length < 3) throw new Error('Need at least 3 data rows.');
        state.company.history = rows; renderData(); recompute();
        $('#csvMsg').innerHTML = statusChip('good', `Imported ${rows.length} months.`);
      } catch (err) { $('#csvMsg').innerHTML = statusChip('critical', err.message); }
    };
    $('#copyCsvBtn').onclick = async () => {
      const csv = ['month,revenue,cogs,payroll,rent,other_opex', ...state.company.history.map((m) => [m.month, m.revenue, m.cogs, m.payroll, m.rent, m.otherOpex].join(','))].join('\n');
      try { await navigator.clipboard.writeText(csv); toast('Copied CSV to clipboard.'); } catch (e) { $('#csvIn').value = csv; toast('Clipboard blocked: the CSV is in the box above.'); }
    };
  }
  function parseCSV(text) {
    const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    if (!lines.length) throw new Error('Nothing to import.');
    const split = (l) => { const out = []; let cur = '', q = false; for (const ch of l) { if (ch === '"') q = !q; else if (ch === ',' && !q) { out.push(cur); cur = ''; } else cur += ch; } out.push(cur); return out.map((s) => s.trim()); };
    let header = split(lines[0]).map((h) => h.toLowerCase().replace(/[^a-z]/g, ''));
    const want = { month: ['month', 'period', 'date'], revenue: ['revenue', 'sales'], cogs: ['cogs', 'costofgoodssold', 'costofsales'], payroll: ['payroll', 'wages', 'salaries'], rent: ['rent'], otherOpex: ['otheropex', 'otherexpenses', 'other', 'opex'] };
    let idx = {};
    for (const [k, names] of Object.entries(want)) idx[k] = header.findIndex((h) => names.includes(h));
    let body = lines.slice(1);
    if (idx.month < 0 || idx.revenue < 0) { idx = { month: 0, revenue: 1, cogs: 2, payroll: 3, rent: 4, otherOpex: 5 }; if (!isNaN(parseFloat(split(lines[0])[1]))) body = lines; }
    const num = (s) => { if (s == null || s === '') return 0; const neg = /^\(.*\)$/.test(s); const v = parseFloat(s.replace(/[$,()\s]/g, '')); if (!isFinite(v)) throw new Error(`"${s}" is not a number.`); return neg ? -v : v; };
    return body.map((l, i) => {
      const c = split(l);
      const row = { month: c[idx.month] || `Month ${i + 1}` };
      for (const k of ['revenue', 'cogs', 'payroll', 'rent', 'otherOpex']) row[k] = idx[k] >= 0 ? num(c[idx[k]]) : 0;
      if (!(row.revenue > 0)) throw new Error(`Row ${i + 1}: revenue must be above zero.`);
      return row;
    });
  }

  // ---------------- AI advisor ----------------
  let sample = null, aiChecked = false, aiAbort = null;
  const API_KEY_STORE = 'decision-lab.apikey', API_MODEL_STORE = 'decision-lab.apimodel';
  const lsGet = (k) => { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } };
  const lsSet = (k, v) => { try { if (v) localStorage.setItem(k, v); else localStorage.removeItem(k); return true; } catch (e) { return false; } };
  let apiKey = lsGet(API_KEY_STORE), apiModel = lsGet(API_MODEL_STORE) || 'claude-sonnet-5-5';
  const MODEL_NAMES = { 'claude-sonnet-5-5': 'Sonnet 5.5', 'claude-haiku-5-5': 'Haiku 5.5', 'claude-opus-5-5': 'Opus 5.5' };
  /** Direct call to the Anthropic Messages API with the user's own key, streamed. Same shape as the claude.ai sample() call. */
  async function apiSample(input, opts) {
    let res;
    try {
      res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST', signal: opts.signal,
        headers: { 'content-type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
        body: JSON.stringify({ model: apiModel, max_tokens: 1500, stream: true, messages: [{ role: 'user', content: input }] }),
      });
    } catch (e) {
      if (e.name === 'AbortError') throw e;
      const err = new Error('Could not reach api.anthropic.com. Check your internet connection. (Inside claude.ai, outside calls are blocked; use the built-in AI there.)'); err.code = 'network'; throw err;
    }
    if (!res.ok) {
      let msg = ''; try { const j = await res.json(); msg = j.error && j.error.message; } catch (e) { /* ignore */ }
      const err = new Error(msg || `HTTP ${res.status}`);
      err.code = res.status === 401 || res.status === 403 ? 'bad_key' : res.status === 429 || res.status === 529 ? 'rate_limited' : 'api_error';
      throw err;
    }
    const reader = res.body.getReader(), dec = new TextDecoder();
    let buf = '', text = '', stop = null;
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf('\n\n')) >= 0) {
        const evt = buf.slice(0, i); buf = buf.slice(i + 2);
        const line = evt.split('\n').find((l) => l.startsWith('data:'));
        if (!line) continue;
        let d; try { d = JSON.parse(line.slice(5)); } catch (e) { continue; }
        if (d.type === 'content_block_delta' && d.delta && d.delta.type === 'text_delta') { text += d.delta.text; if (opts.onText) opts.onText({ text, delta: d.delta.text }); }
        else if (d.type === 'message_delta' && d.delta) stop = d.delta.stop_reason;
        else if (d.type === 'error') { const err = new Error((d.error && d.error.message) || 'API error'); err.code = 'api_error'; throw err; }
      }
    }
    return { text, truncated: stop === 'max_tokens' };
  }
  const aiFn = () => sample || (apiKey ? apiSample : null);
  function bindApiCard() {
    $('#apiKeyIn').value = apiKey ? '••••••••' + apiKey.slice(-4) : '';
    $('#apiModelSel').value = apiModel;
    $('#apiKeyIn').onfocus = (e) => { if (e.target.value.startsWith('••')) e.target.value = ''; };
    $('#apiSave').onclick = () => {
      const v = $('#apiKeyIn').value.trim();
      if (v && !v.startsWith('••')) {
        if (!/^sk-ant-/.test(v)) { $('#apiMsg').innerHTML = statusChip('warning', 'That doesn\u2019t look like an Anthropic key (they start with sk-ant-).'); return; }
        apiKey = v;
      }
      apiModel = $('#apiModelSel').value;
      if (!apiKey) { $('#apiMsg').innerHTML = statusChip('warning', 'Paste a key first.'); return; }
      const saved = lsSet(API_KEY_STORE, apiKey) && lsSet(API_MODEL_STORE, apiModel);
      $('#apiKeyIn').value = '••••••••' + apiKey.slice(-4);
      $('#apiMsg').innerHTML = statusChip('good', saved ? 'Saved in this browser. The AI advisor is on.' : 'Turned on for this session (this browser can\u2019t store it).');
      renderAIStatus();
    };
    $('#apiClear').onclick = () => { apiKey = ''; lsSet(API_KEY_STORE, ''); $('#apiKeyIn').value = ''; $('#apiMsg').innerHTML = statusChip('good', 'Key removed from this browser.'); renderAIStatus(); };
  }
  async function initAI() {
    const tryUse = async () => {
      if (!(window.claude && typeof window.claude.use === 'function')) return null;
      try { return await window.claude.use('sample'); } catch (e) { return null; }
    };
    sample = await tryUse();
    if (!sample) { await new Promise((r) => setTimeout(r, 1500)); sample = await tryUse(); }
    aiChecked = true; renderAIStatus();
  }
  function renderAIStatus() {
    $('#aiStatus').innerHTML = !aiChecked ? '<span class="dot"></span>Checking…' : sample ? '<span class="dot on"></span>AI connected' : apiKey ? `<span class="dot on"></span>AI on (your key · ${esc(MODEL_NAMES[apiModel] || apiModel)})` : '<span class="dot"></span>AI off: rule-based summaries';
    $('#apiCard').hidden = !aiChecked || !!sample;
  }
  const r0 = (v) => (v == null || !isFinite(v) ? null : Math.round(v / 100) * 100);
  const p1 = (v) => (v == null || !isFinite(v) ? null : Math.round(v * 1000) / 10);
  const x2 = (v) => (v == null || !isFinite(v) ? null : Math.round(v * 100) / 100);
  function buildPayload(kind) {
    const c = state.company, T = state.today, m = state.settings.months, R = state.results;
    const base = R[0];
    const scen = R.map((r, i) => {
      const o = {
        name: r.scenario.name, role: i === 0 ? 'baseline: no changes' : SC_TAGS[i],
        decisions: r.scenario.decisions.filter((d) => d.enabled !== false).map((d) => E.DECISIONS[d.type].summary(d.params)),
        chance_of_running_out_of_cash_pct: p1(r.mc.probCashOut),
        expected_end_cash: r0(r.expected.rows[m - 1].cash),
        pessimistic_end_cash_p10: r0(r.mc.endCash.p10), optimistic_end_cash_p90: r0(r.mc.endCash.p90),
        lowest_expected_cash: r0(r.expected.minCash), lowest_cash_month: r.expected.minCashMonth ? futureLabel(r.expected.minCashMonth) : 'today',
        first_month_expected_cash_negative: r.expected.cashOutMonth ? futureLabel(r.expected.cashOutMonth) : null,
        total_revenue: r0(r.totals.revenue), total_net_income: r0(r.totals.netIncome), total_free_cash_flow: r0(r.totals.fcf),
        net_margin_end_pct: p1(r.endRatios.netMargin), worst_12m_dscr: x2(r.worstDSCR), current_ratio_end: x2(r.endRatios.currentRatio),
        debt_to_equity_end: x2(r.endRatios.debtToEquity), roe_end_pct: p1(r.endRatios.roe), debt_end: r0(r.endRatios.debt),
        warning_flags: r.flags.map((f) => `${f.sev}: ${f.title}`),
      };
      if (i > 0) o.change_vs_baseline = {
        chance_of_running_out_of_cash_pts: p1(r.mc.probCashOut - base.mc.probCashOut),
        expected_end_cash: r0(r.expected.rows[m - 1].cash - base.expected.rows[m - 1].cash),
        pessimistic_end_cash_p10: r0(r.mc.endCash.p10 - base.mc.endCash.p10),
        total_net_income: r0(r.totals.netIncome - base.totals.netIncome),
        lowest_expected_cash: r0(r.expected.minCash - base.expected.minCash),
      };
      return o;
    });
    const today = {
      months_of_history: T.months, revenue_period: r0(T.flows.revenue), net_income_period: r0(T.flows.netIncome),
      revenue_change_first3_vs_last3_pct: p1(T.trend.revenueChange), gross_margin_pct: p1(T.ratios.grossMargin), gross_margin_change_pts: p1(T.trend.gmChange),
      net_margin_pct: p1(T.ratios.netMargin), operating_margin_pct: p1(T.ratios.operatingMargin), roa_pct: p1(T.ratios.roa), roe_pct: p1(T.ratios.roe),
      current_ratio: x2(T.ratios.currentRatio), quick_ratio: x2(T.ratios.quickRatio), debt_to_equity: x2(T.ratios.debtToEquity), debt_to_assets_pct: p1(T.ratios.debtToAssets),
      interest_coverage: x2(T.ratios.interestCoverage), dscr: x2(T.ratios.dscr), dso_days: x2(T.ratios.dso), dio_days: x2(T.ratios.dio), dpo_days: x2(T.ratios.dpo),
      cash_conversion_cycle_days: x2(T.ratios.cashConversionCycle), cash: r0(c.balance.cash), debt: r0(c.balance.debt), equity: r0(T.ratios.equity),
      cash_runway_months: T.ratios.runwayMonths == null ? 'cash-generating' : x2(T.ratios.runwayMonths),
      flags: E.todayFlags(T).map((f) => `${f.sev}: ${f.title}`),
    };
    const P = {
      company: { name: c.name, industry: c.industry, description: c.tagline }, decision_question: c.question,
      horizon_months: m, horizon_ends: futureLabel(m), simulated_futures: state.settings.paths, uncertainty_setting: `${state.settings.volMult}x historical volatility`,
      units: 'Dollar amounts in USD; *_pct fields are percentages; ratios are multiples (x).',
      today,
    };
    if (kind !== 'today') P.scenarios = scen;
    if (kind === 'premortem') {
      const opts = R.slice(1);
      const worst = opts.reduce((a, b) => (b.mc.probCashOut > a.mc.probCashOut || (b.mc.probCashOut === a.mc.probCashOut && b.mc.endCash.p10 < a.mc.endCash.p10) ? b : a));
      P.premortem_target = worst.scenario.name;
      P.premortem_pessimistic_cash_path_p10 = worst.mc.band.map((b, k) => ({ month: futureLabel(k + 1), cash: r0(b.p10) })).filter((_, k) => k % 3 === 2 || k === m - 1);
      P.premortem_expected_monthly = worst.expected.rows.filter((_, k) => k % 3 === 2).map((x) => ({ month: futureLabel(x.t), revenue: r0(x.revenue), net_income: r0(x.netIncome), cash: r0(x.cash) }));
    }
    return P;
  }
  const AUD = {
    owner: 'a busy small-business owner with no finance training. Use plain, warm, direct language. When you mention a ratio, explain it in a few words.',
    analyst: 'a financial analyst. Be concise and technical; standard terminology is fine.',
  };
  const TASKS = {
    compare: { title: 'How your options compare', text: 'Compare each option with the baseline (keeping the current course). Use these headings exactly:\n## Bottom line\n(2–3 sentences: which option looks stronger on risk and on profit, and the key trade-off.)\n## Option by option\n(one short paragraph per option, including the baseline: what it does to cash, risk of running out, and profit.)\n## Biggest risks to watch\n(2–4 bullets)\n## Ways to make the stronger option safer\n(2–4 bullets tied to levers in the data, such as timing, loan size, pricing, cost or working capital.)\n## Questions to check before deciding\n(3 bullets)' },
    premortem: { title: 'Pre-mortem', text: 'Run a pre-mortem on the option named in premortem_target. Imagine it is the end of the horizon and this option went badly. Use these headings exactly:\n## What went wrong (a hypothetical story)\n(about 150 words, vivid but grounded ONLY in the DATA, especially the pessimistic cash path. Make clear this is one plausible bad case, not a prediction.)\n## Early warning signs\n(3 bullets: a measurable signal and the threshold to watch, using metrics in DATA)\n## How to prevent it\n(3–4 bullets of concrete levers)' },
    today: { title: "Today's financial health", text: "Explain the company's current financial health from the `today` data. Use these headings exactly:\n## Summary\n(2–3 sentences)\n## Strengths\n(bullets)\n## Concerns\n(bullets, most serious first)\n## What the key ratios mean here\n(4 bullets: ratio, value, what it means for this business)\n## Questions to ask your accountant\n(3 bullets)" },
    question: { title: 'Your question', text: "Answer the user's question below using the DATA. If it cannot be answered from DATA, say what extra information or which scenario they could set up in the app to answer it (for example adding a decision to Option A or B). Keep it under 250 words." },
  };
  function buildPrompt(kind, payload, question) {
    return `You are the AI advisor inside "Decision Lab", a financial decision-support tool for small businesses.
Your reader is ${AUD[$('#audienceSel').value]}

RULES
- Use ONLY the figures in DATA. They were calculated by the app's engine. Interpret them; never invent, estimate or recalculate numbers. When you cite a figure, copy it from DATA (rounding is fine, e.g. $1.2M).
- Do not introduce outside statistics, benchmarks or facts about the company that are not in DATA.
- This is informational analysis, not financial advice. Frame suggestions as considerations ("consider", "it may be worth"), never as instructions or guarantees.
- If DATA is not enough to judge something, say so plainly.
- Output Markdown only: ## headings, short paragraphs, "- " bullets, **bold** for emphasis. No tables. Under 400 words.

TASK
${TASKS[kind].text}${question ? `\n\nUSER QUESTION: ${question}` : ''}

DATA
${JSON.stringify(payload, null, 1)}`;
  }
  function mdToHTML(md) {
    const lines = esc(md).split(/\n/);
    let html = '', list = null;
    const inline = (s) => s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/(^|[^*])\*(?!\s)(.+?)\*(?!\*)/g, '$1<em>$2</em>').replace(/`([^`]+)`/g, '<code>$1</code>');
    const close = () => { if (list) { html += `</${list}>`; list = null; } };
    for (const raw of lines) {
      const l = raw.trimEnd();
      let m;
      if ((m = /^#{1,4}\s+(.*)$/.exec(l))) { close(); html += `<h3>${inline(m[1])}</h3>`; }
      else if ((m = /^\s*[-*•]\s+(.*)$/.exec(l))) { if (list !== 'ul') { close(); html += '<ul>'; list = 'ul'; } html += `<li>${inline(m[1])}</li>`; }
      else if ((m = /^\s*\d+[.)]\s+(.*)$/.exec(l))) { if (list !== 'ol') { close(); html += '<ol>'; list = 'ol'; } html += `<li>${inline(m[1])}</li>`; }
      else if (!l.trim()) close();
      else { close(); html += `<p>${inline(l)}</p>`; }
    }
    close();
    return html;
  }
  /** Check every $ amount, percentage and multiple in the AI text against the numbers that were sent. */
  function numberCheck(text, payload) {
    const allowed = [];
    (function walk(o) { if (o == null) return; if (typeof o === 'number') { allowed.push(o, Math.abs(o)); return; } if (typeof o === 'string') { const n = o.match(/-?\$?\d[\d,]*\.?\d*/g); if (n) n.forEach((s) => { const v = parseFloat(s.replace(/[$,]/g, '')); if (isFinite(v)) allowed.push(v, Math.abs(v)); }); return; } if (typeof o === 'object') Object.values(o).forEach(walk); })(payload);
    const re = /([−-])?\$\s?(\d[\d,]*(?:\.\d+)?)\s?(k|K|M|m|million|thousand|B|billion)?\b|([−-])?(\d+(?:\.\d+)?)\s?(%|percent|pts|percentage points|×|x\b)/g;
    const found = []; let m;
    while ((m = re.exec(text))) {
      if (m[2] != null) {
        const mult = /^(k|K|thousand)$/.test(m[3] || '') ? 1e3 : /^(M|m|million)$/.test(m[3] || '') ? 1e6 : /^(B|billion)$/.test(m[3] || '') ? 1e9 : 1;
        found.push({ raw: m[0].trim(), v: parseFloat(m[2].replace(/,/g, '')) * mult, kind: 'money' });
      } else {
        found.push({ raw: m[0].trim(), v: parseFloat(m[5]), kind: /×|x/.test(m[6]) ? 'x' : 'pct' });
      }
    }
    const ok = (f) => allowed.some((a) => {
      const A = Math.abs(a);
      if (f.kind === 'money') return Math.abs(f.v - A) <= Math.max(0.06 * A, 150);
      if (f.kind === 'pct') return Math.abs(f.v - A) <= Math.max(0.6, 0.06 * A) || (A <= 1.5 && Math.abs(f.v - A * 100) <= 0.6);
      return Math.abs(f.v - A) <= Math.max(0.05, 0.05 * A);
    });
    // thresholds the AI is allowed to quote from the method (e.g. 1.25× DSCR, 10th percentile, 80%/50% bands)
    const known = [1.25, 1, 2, 3, 10, 50, 80, 90, 100];
    const bad = found.filter((f) => !ok(f) && !(f.kind !== 'money' && known.includes(f.v)));
    return { total: found.length, bad };
  }
  async function runAI(kind, question) {
    if (!state.results) return;
    gotoTab('ai');
    const payload = buildPayload(kind);
    $('#aiPayload').textContent = JSON.stringify(payload, null, 2);
    $('#aiTitle').textContent = TASKS[kind].title;
    $('#aiCheck').innerHTML = '';
    const out = $('#aiOut'), card = $('#aiCard');
    if (aiAbort) aiAbort.abort();
    const callAI = aiFn();
    if (!callAI) {
      card.classList.add('rule'); $('#aiPill').className = 'pill rule'; $('#aiPill').textContent = 'Rule-based summary';
      $('#aiNoteText').textContent = 'This summary was assembled by fixed rules from the calculated results. No AI was used. This is informational, not financial advice.';
      out.innerHTML = `<p class="muted small">AI isn't turned on in this copy. To turn it on, add an Anthropic API key under "Turn on AI in this copy". This summary was assembled by fixed rules from the calculated results.</p>` + mdToHTML(fallbackText(kind, question));
      return;
    }
    card.classList.remove('rule'); $('#aiPill').className = 'pill ai'; $('#aiNoteText').textContent = 'This text was written by AI from the calculated results shown in the app. It may contain mistakes or miss context. Every figure it quotes is checked against the app\u2019s calculations above. This is informational, not financial advice.'; $('#aiPill').textContent = 'AI-generated';
    out.innerHTML = '<p class="muted typing">Thinking</p>';
    aiAbort = new AbortController();
    $('#aiStop').hidden = false;
    $$('[data-ai], #askBtn').forEach((b) => (b.disabled = true));
    let finalText = '';
    try {
      const res = await callAI(buildPrompt(kind, payload, question), {
        signal: aiAbort.signal, modelTier: 'default',
        onText: ({ text }) => { finalText = text; out.innerHTML = mdToHTML(text); out.lastElementChild && out.lastElementChild.classList.add('typing'); },
      });
      finalText = res.text || finalText;
      out.innerHTML = mdToHTML(finalText) + (res.truncated ? '<p class="muted small">(Response was cut short.)</p>' : '');
      const chk = numberCheck(finalText, payload);
      $('#aiCheck').innerHTML = `<div class="check">${chk.bad.length === 0
        ? statusChip('good', chk.total ? `Number check: ${chk.total === 1 ? 'the one figure' : `all ${chk.total} figures`} in this answer ${chk.total === 1 ? 'matches' : 'match'} the app's calculated results.` : 'Number check: this answer quotes no figures.')
        : statusChip('warning', `Number check: ${chk.bad.length} of ${chk.total} figures could not be matched to calculated results: ${chk.bad.slice(0, 6).map((b) => b.raw).join(', ')}. Treat them with caution.`)}</div>`;
    } catch (err) {
      if (err && err.name === 'AbortError') { out.insertAdjacentHTML('beforeend', '<p class="muted small">Stopped.</p>'); }
      else if (err && err.code === 'not_granted') { sample = null; renderAIStatus(); runAI(kind, question); }
      else if (err && err.code === 'bad_key') { out.innerHTML = `<p>The API key was rejected (${esc(err.message)}). Check it under "Turn on AI in this copy".</p>`; }
      else if (err && err.code === 'rate_limited') { out.innerHTML = '<p>The AI is busy right now. Please wait a minute and try again.</p>'; }
      else { out.innerHTML = `<p>The AI request failed (${esc(err && (err.message || err.code) || 'unknown error')}). Here is the rule-based summary instead.</p>` + mdToHTML(fallbackText(kind, question)); }
    } finally {
      $('#aiStop').hidden = true; aiAbort = null;
      $$('[data-ai], #askBtn').forEach((b) => (b.disabled = false));
      $$('.typing', out).forEach((el) => el.classList.remove('typing'));
    }
  }
  function fallbackText(kind, question) {
    const R = state.results, m = state.settings.months, T = state.today;
    if (kind === 'today') {
      const fl = E.todayFlags(T);
      return `## Summary\nOver the last ${T.months} months revenue totalled ${money(T.flows.revenue)} with net income of ${money(T.flows.netIncome)} (net margin ${pct(T.ratios.netMargin)}).\n## Strengths\n${fl.filter((f) => f.sev === 'good').map((f) => `- ${f.title}`).join('\n') || '- None detected by the rules.'}\n## Concerns\n${fl.filter((f) => f.sev !== 'good').map((f) => `- **${f.title}**: ${f.detail}`).join('\n') || '- None detected by the rules.'}`;
    }
    const ranked = R.slice(1).slice().sort((a, b) => a.mc.probCashOut - b.mc.probCashOut || b.totals.netIncome - a.totals.netIncome);
    const lines = R.map((r) => `- **${r.scenario.name}**: ${pct(r.mc.probCashOut)} chance of running out of cash; expected cash ${money(r.expected.rows[m - 1].cash)} in ${futureLabel(m)}; total net income ${money(r.totals.netIncome)}.`).join('\n');
    if (kind === 'premortem') {
      const w = ranked[ranked.length - 1];
      return `## Riskiest option: ${w.scenario.name}\nIn the pessimistic case (10th percentile) cash ends at ${money(w.mc.endCash.p10)}. Lowest expected cash is ${money(w.expected.minCash)} in ${w.expected.minCashMonth ? futureLabel(w.expected.minCashMonth) : 'month 0'}.\n## Warning signs flagged\n${w.flags.map((f) => `- **${f.title}**: ${f.detail}`).join('\n')}`;
    }
    const best = ranked[0];
    return `${question ? `## Your question\nFree-form questions need the AI, which isn't available here. Here are the calculated results that are most relevant.\n` : ''}## Results at a glance\n${lines}\n## Lowest-risk option\n**${best.scenario.name}** has the lowest chance of running out of cash among the options (${pct(best.mc.probCashOut)}, versus ${pct(R[0].mc.probCashOut)} if nothing changes).\n## Flags to review\n${R.slice(1).map((r) => `- ${r.scenario.name}: ${r.flags.filter((f) => f.sev !== 'good').map((f) => f.title).join('; ') || 'no warnings'}`).join('\n')}`;
  }

  // ---------------- method page ----------------
  function renderMethod() {
    $('#methodProse').innerHTML = `
<h2 style="margin-top:0">The problem this solves</h2>
<p>Small-business owners make their biggest financial decisions (hiring, borrowing, expanding, repricing) mostly on gut feel. Statements show where the business has been, not what a decision will do to it, and a single spreadsheet forecast hides the real question: <em>how likely is it that this goes wrong?</em> Decision Lab turns a business's own numbers into a side-by-side comparison of options, with the odds of running out of cash front and center.</p>
<h2>What is calculated and what is AI</h2>
<p>Every number, chart, ratio and warning comes from a deterministic calculation engine. You can check each one against the formulas below. The AI advisor receives only those finished numbers, shown under "See exactly what data was sent to the AI". It writes an interpretation, labeled <span class="pill ai">AI-generated</span>. After each answer the app checks every dollar figure, percentage and multiple in the AI's text against the calculated values, and flags any it cannot match.</p>
<h2>How the forecast works</h2>
<h3>1. Learning from history</h3>
<p>Revenue trend: a straight line is fitted to the logarithm of monthly revenue (least squares), giving a monthly growth rate. The scatter of actual months around that line measures normal volatility. The fit's standard error measures how uncertain the growth rate itself is. Gross margin is the average of the last 6 months. Operating expenses are the average of the last 3 months, grown by your cost-inflation rate. Days sales outstanding, days inventory and days payables come from today's balance sheet against the last 3 months of activity.</p>
<h3>2. Projecting each month</h3>
<p><code>Revenue = trend × volume effects × price effects</code>, and <code>COGS = units × (1 − gross margin) × supplier-cost effects</code>. A price change therefore moves revenue and margin while unit costs stay the same. Volume responds through the elasticity you set. Then: <code>EBITDA = Revenue − COGS − OpEx − one-time items</code>, minus depreciation and interest, gives pre-tax profit. Tax applies only to positive profit. Receivables, inventory and payables scale with activity, so growth ties up cash. <code>Operating cash flow = Net income + Depreciation − Δ working capital</code>, and cash moves by operating cash flow, minus capex, plus new borrowing, minus loan principal. Loans amortize with a standard payment schedule.</p>
<h3>3. Simulating many futures (Monte Carlo)</h3>
<p>Each simulated future draws its own growth rate (from the trend's uncertainty), month-to-month revenue swings (these persist from month to month, with a correlation of 0.6, and stay centered on the trend), and gross-margin noise, all sized from your own history. The <em>Uncertainty</em> setting scales these swings. The chance of running out of cash is the share of futures in which cash falls below zero at any point. Every option is run against <strong>the same set of random futures</strong>, so differences between options come from the decision, not from luck. Results are reproducible.</p>
<h2>Ratios</h2>
<p>Today's ratios use the full history window for income items and today's balance sheet. End-of-period ratios use the last 3 projected months, annualized where relevant. If a plan runs cash below zero, the shortfall is treated as short-term borrowing so that the ratios stay meaningful. DSCR in the comparison is the worst trailing 12-month EBITDA divided by loan payments, which is how lenders usually test it.</p>
<h2>Warning signs</h2>
<p>Rules flag, among other things: cash-out probability ≥ 3% / 10% / 25%; an expected path that goes negative; a cash cushion below one month of expenses; DSCR below 1.25× or 1.0×; interest coverage below 1.5×; debt-to-equity above 2× or 3×; negative equity; current ratio below 1; likely net loss; gross-margin erosion; shrinking sales; slow collections; and runway under 6 or 12 months. Unusual months are found with a robust z-score (median-based) on month-over-month changes.</p>
<h2>Limitations</h2>
<ul><li>The model is only as good as the inputs. Garbage in, garbage out.</li><li>It extrapolates recent trends. It doesn't know about seasonality beyond what's in the history, new competitors, or economic shocks larger than the volatility setting.</li><li>Taxes, depreciation and loan terms are simplified. Check details with your accountant.</li><li>Decision effects (such as revenue per hire or price elasticity) are your assumptions. Try pessimistic values too.</li></ul>
<h2>Disclaimer</h2>
<p>Decision Lab provides informational analysis only. It is not investment, tax, legal, lending or accounting advice, and projections are not guarantees of future results. AI-generated commentary may be inaccurate or incomplete. Consult a qualified professional before making significant financial decisions.</p>`;
  }

  // ---------------- tabs & shell ----------------
  const VIEWS = ['lab', 'today', 'detail', 'ai', 'data', 'method'];
  function gotoTab(v) {
    if (!VIEWS.includes(v)) v = 'lab';
    $$('nav.tabs button').forEach((b) => b.setAttribute('aria-selected', b.dataset.view === v));
    $$('section.view').forEach((s) => s.classList.toggle('active', s.id === `view-${v}`));
    state.ui.tab = v;
    if (location.hash.slice(1) !== v) { try { history.replaceState(null, '', `#${v}`); } catch (e) { location.hash = v; } }
    renderActive();
  }
  function renderActive() {
    if (state.error || !state.results) return;
    const v = state.ui.tab || 'lab';
    if (v === 'lab') { renderFan(); renderRiskChart(); }
    if (v === 'today') renderToday();
    if (v === 'detail') renderDetail();
  }
  function renderResults() {
    const err = $('#errBox');
    if (state.error) {
      if (!err) $('main').insertAdjacentHTML('afterbegin', `<div id="errBox" class="card" style="margin-bottom:16px;border-color:var(--critical)">${statusChip('critical', 'Can’t calculate yet')}<p class="small" style="margin:6px 0 0" id="errMsg"></p></div>`);
      $('#errMsg').textContent = state.error; return;
    }
    if (err) err.remove();
    renderVerdicts(); renderCompare(); renderFlagCols();
    renderActive();
  }
  function renderCompanySel() {
    const opts = SAMPLES.map((s) => `<option value="${s.id}">${esc(s.name)} (sample)</option>`);
    if (state.companyId === 'custom' || (store.companies && store.companies.custom)) opts.push(`<option value="custom">${esc((store.companies && store.companies.custom && store.companies.custom.company.name) || 'My business')}</option>`);
    $('#companySel').innerHTML = opts.join('');
    $('#companySel').value = state.companyId;
  }
  function fullRender() {
    $('#questionIn').value = state.company.question || '';
    recompute();
    renderScenarioCols();
    renderData();
  }
  function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove('show'), 2600); }

  function init() {
    chartDefaults();
    if (!SAMPLES.some((s) => s.id === state.companyId) && !(store.companies && store.companies[state.companyId])) state.companyId = SAMPLES[0].id;
    loadCompany(state.companyId);
    renderCompanySel();
    $('#horizonSel').value = String(state.settings.months);
    $('#volSel').value = String(state.settings.volMult);
    $('#pathsSel').value = String(state.settings.paths);
    renderMethod();
    bindScenarioEvents();
    bindData();
    $('#companySel').onchange = (e) => { save(); loadCompany(e.target.value); fullRender(); };
    $('#horizonSel').onchange = (e) => {
      state.settings.months = +e.target.value;
      state.scenarios.forEach((sc) => sc.decisions.forEach((d) => { for (const k of ['start', 'month']) if (d.params[k] > state.settings.months) d.params[k] = state.settings.months; }));
      renderScenarioCols(); recompute();
    };
    $('#volSel').onchange = (e) => { state.settings.volMult = +e.target.value; recompute(); };
    $('#pathsSel').onchange = (e) => { state.settings.paths = +e.target.value; recompute(); };
    $('#questionIn').oninput = (e) => { state.company.question = e.target.value; save(); };
    $$('nav.tabs button').forEach((b) => (b.onclick = () => gotoTab(b.dataset.view)));
    document.addEventListener('click', (e) => {
      const a = e.target.closest('[data-tab]'); if (a) { e.preventDefault(); gotoTab(a.dataset.tab); }
      const g = e.target.closest('[data-goto-ai]'); if (g) runAI(g.dataset.gotoAi);
      const s = e.target.closest('#fanSeg button'); if (s) { state.ui.fan = +s.dataset.i; renderFan(); }
      const d = e.target.closest('#detailSeg button'); if (d) { state.ui.detail = +d.dataset.i; renderDetail(); }
    });
    $$('[data-ai]').forEach((b) => (b.onclick = () => runAI(b.dataset.ai)));
    $('#askBtn').onclick = () => { const q = $('#askIn').value.trim(); if (!q) return toast('Type a question first.'); runAI('question', q.slice(0, 1000)); };
    $('#aiStop').onclick = () => aiAbort && aiAbort.abort();
    window.addEventListener('hashchange', () => gotoTab(location.hash.slice(1)));
    try { window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { chartDefaults(); renderResults(); }); } catch (e) { /* old browsers */ }
    fullRender();
    gotoTab(location.hash.slice(1) || 'lab');
    bindApiCard();
    renderAIStatus();
    initAI();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();

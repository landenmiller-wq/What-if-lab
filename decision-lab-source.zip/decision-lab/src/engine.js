/*
 * Decision Lab — calculation engine
 * Pure functions, no DOM. Every number the app shows comes from here.
 * The AI layer only ever receives the outputs of these functions.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Engine = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const DPM = 365 / 12; // average days per month, used for DSO / DIO / DPO

  // ---------- small math helpers ----------
  const sum = (a) => a.reduce((s, x) => s + x, 0);
  const mean = (a) => (a.length ? sum(a) / a.length : 0);
  function std(a, ddof = 1) {
    if (a.length <= ddof) return 0;
    const m = mean(a);
    return Math.sqrt(sum(a.map((x) => (x - m) ** 2)) / (a.length - ddof));
  }
  function median(a) {
    if (!a.length) return 0;
    const s = [...a].sort((x, y) => x - y);
    const mid = Math.floor(s.length / 2);
    return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
  }
  /** Percentile with linear interpolation (same as numpy's default). p in [0,100]. */
  function percentile(sorted, p) {
    if (!sorted.length) return 0;
    const idx = (p / 100) * (sorted.length - 1);
    const lo = Math.floor(idx), hi = Math.ceil(idx);
    return sorted[lo] + (sorted[hi] - sorted[lo]) * (idx - lo);
  }
  /** Ordinary least squares y = a + b x. Returns slope, intercept, residuals, slope standard error. */
  function linreg(xs, ys) {
    const n = xs.length;
    const mx = mean(xs), my = mean(ys);
    let sxx = 0, sxy = 0;
    for (let i = 0; i < n; i++) { sxx += (xs[i] - mx) ** 2; sxy += (xs[i] - mx) * (ys[i] - my); }
    const slope = sxx === 0 ? 0 : sxy / sxx;
    const intercept = my - slope * mx;
    const residuals = ys.map((y, i) => y - (intercept + slope * xs[i]));
    const s2 = n > 2 ? sum(residuals.map((r) => r * r)) / (n - 2) : 0;
    const slopeSE = sxx === 0 ? 0 : Math.sqrt(s2 / sxx);
    return { slope, intercept, residuals, residualSD: Math.sqrt(s2), slopeSE };
  }
  /** Standard loan payment (annuity). rate = periodic rate. */
  function pmt(rate, n, principal) {
    if (n <= 0) return principal;
    if (rate === 0) return principal / n;
    return (principal * rate) / (1 - Math.pow(1 + rate, -n));
  }
  /** Robust z-scores using the median absolute deviation. */
  function robustZ(a) {
    const m = median(a);
    const mad = median(a.map((x) => Math.abs(x - m)));
    if (mad === 0) return a.map(() => 0);
    return a.map((x) => (0.6745 * (x - m)) / mad);
  }

  // ---------- seeded randomness (so results are reproducible and comparable) ----------
  function mulberry32(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6d2b79f5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function normalGen(seed) {
    const u = mulberry32(seed);
    let spare = null;
    return function () {
      if (spare !== null) { const s = spare; spare = null; return s; }
      let a, b, r;
      do { a = u() * 2 - 1; b = u() * 2 - 1; r = a * a + b * b; } while (r === 0 || r >= 1);
      const f = Math.sqrt((-2 * Math.log(r)) / r);
      spare = b * f;
      return a * f;
    };
  }

  // ---------- history analysis ----------
  const opexOf = (m) => (m.payroll || 0) + (m.rent || 0) + (m.otherOpex || 0);

  /** Derive forecasting assumptions from monthly history + balance sheet. */
  function deriveAssumptions(company) {
    const h = company.history;
    const n = h.length;
    if (n < 3) throw new Error('At least 3 months of history are needed.');
    const xs = h.map((_, i) => i);
    const logRev = h.map((m) => Math.log(Math.max(1, m.revenue)));
    const lr = linreg(xs, logRev);
    const gmSeries = h.map((m) => (m.revenue > 0 ? 1 - m.cogs / m.revenue : 0));
    const last = (k) => h.slice(Math.max(0, n - k));
    const rev3 = mean(last(3).map((m) => m.revenue));
    const cogs3 = mean(last(3).map((m) => m.cogs));
    const bs = company.balance;
    const derived = {
      startRevenue: Math.exp(lr.intercept + lr.slope * (n - 1)), // trend value for the last month (de-noised)
      lastRevenue: h[n - 1].revenue,
      growth: Math.exp(lr.slope) - 1, // monthly trend growth
      growthSE: lr.slopeSE, // uncertainty in the monthly log-growth estimate
      revVol: lr.residualSD, // monthly deviation around trend (log)
      grossMargin: mean(last(6).map((m) => 1 - m.cogs / m.revenue)),
      gmVol: std(gmSeries),
      fixedOpex: mean(last(3).map(opexOf)),
      dso: rev3 > 0 ? (bs.ar / rev3) * DPM : 0,
      dio: cogs3 > 0 ? (bs.inventory / cogs3) * DPM : 0,
      dpo: cogs3 > 0 ? (bs.ap / cogs3) * DPM : 0,
      costInflation: company.costInflation ?? 0.03,
      taxRate: company.taxRate ?? 0.25,
      depreciation: company.depreciation ?? 0,
      capex: company.capex ?? 0,
    };
    return Object.assign(derived, company.overrides || {});
  }

  /** Remaining-principal schedule helper: principal due over the next k months. */
  function principalDueNext(loans, k) {
    let due = 0;
    for (const l of loans) {
      let bal = l.balance;
      for (let i = 0; i < k && bal > 0.005; i++) {
        const int = (bal * l.apr) / 12;
        const pr = Math.min(bal, Math.max(0, l.payment - int));
        due += pr; bal -= pr;
      }
    }
    return due;
  }

  /** Ratios from a balance sheet + a trailing window of income items (window = months covered). */
  function ratioSet(b, flows, months, loans) {
    const annual = 12 / months;
    const currentDebt = principalDueNext(loans, 12);
    const ca = b.cash + b.ar + b.inventory + b.otherCurrentAssets;
    const cl = b.ap + b.accrued + currentDebt;
    const debt = sum(loans.map((l) => l.balance));
    const ta = ca + b.fixedAssets + b.otherAssets;
    const tl = b.ap + b.accrued + debt;
    const equity = ta - tl;
    const rev = flows.revenue, ni = flows.netIncome;
    const div = (a, c) => (c === 0 || !isFinite(c) ? null : a / c);
    const debtService = flows.interest + flows.principal;
    return {
      revenueAnnualized: rev * annual,
      grossMargin: div(flows.grossProfit, rev),
      operatingMargin: div(flows.ebit, rev),
      netMargin: div(ni, rev),
      ebitdaMargin: div(flows.ebitda, rev),
      roa: div(ni * annual, ta),
      roe: equity > 0 ? ni * annual / equity : null,
      currentRatio: div(ca, cl),
      quickRatio: div(b.cash + b.ar, cl),
      cashRatio: div(b.cash, cl),
      debtToEquity: equity > 0 ? debt / equity : null,
      debtToAssets: div(debt, ta),
      interestCoverage: flows.interest > 0 ? flows.ebit / flows.interest : null,
      dscr: debtService > 0 ? flows.ebitda / debtService : null,
      dso: rev > 0 ? (b.ar / (rev / months)) * DPM : null,
      dio: flows.cogs > 0 ? (b.inventory / (flows.cogs / months)) * DPM : null,
      dpo: flows.cogs > 0 ? (b.ap / (flows.cogs / months)) * DPM : null,
      totalAssets: ta, totalLiabilities: tl, equity, debt, currentAssets: ca, currentLiabilities: cl,
    };
  }
  function addCCC(r) {
    r.cashConversionCycle = r.dso != null && r.dio != null && r.dpo != null ? r.dso + r.dio - r.dpo : null;
    return r;
  }

  /** "Today" view: trailing-twelve-month (or all history) income + current balance sheet. */
  function analyzeToday(company) {
    const a = deriveAssumptions(company);
    const h = company.history;
    const b = company.balance;
    const loans = b.debt > 0 ? [{ name: 'Existing debt', balance: b.debt, apr: b.debtApr || 0, payment: b.debtPayment || 0 }] : [];
    const months = h.length;
    const revenue = sum(h.map((m) => m.revenue));
    const cogs = sum(h.map((m) => m.cogs));
    const opex = sum(h.map(opexOf));
    const ebitda = revenue - cogs - opex;
    const dep = a.depreciation * months;
    const ebit = ebitda - dep;
    // Interest over the history window: estimated from the current balance (history has no interest line)
    const interest = loans.length ? (b.debt * (b.debtApr || 0) / 12) * months : 0;
    const principal = loans.length ? Math.max(0, (b.debtPayment || 0) - b.debt * (b.debtApr || 0) / 12) * months : 0;
    const ebt = ebit - interest;
    const tax = Math.max(0, ebt) * a.taxRate;
    const netIncome = ebt - tax;
    const flows = { revenue, cogs, grossProfit: revenue - cogs, ebitda, ebit, interest, principal, netIncome };
    const ratios = addCCC(ratioSet(b, flows, months, loans));
    // Monthly operating cash burn (approx.: EBITDA - interest - principal - capex - tax, per month)
    const monthlyNet = (ebitda - interest - principal - tax) / months - a.capex;
    ratios.runwayMonths = monthlyNet < 0 ? b.cash / -monthlyNet : null;
    ratios.monthlyNetCash = monthlyNet;
    // Growth facts
    const first3 = mean(h.slice(0, 3).map((m) => m.revenue));
    const last3 = mean(h.slice(-3).map((m) => m.revenue));
    const gmFirst3 = mean(h.slice(0, 3).map((m) => 1 - m.cogs / m.revenue));
    const gmLast3 = mean(h.slice(-3).map((m) => 1 - m.cogs / m.revenue));
    const series = h.map((m) => {
      const gp = m.revenue - m.cogs;
      const op = gp - opexOf(m);
      return { month: m.month, revenue: m.revenue, grossProfit: gp, opex: opexOf(m), operatingProfit: op, grossMargin: gp / m.revenue };
    });
    return {
      assumptions: a, flows, ratios, months, series, loans,
      trend: { first3Revenue: first3, last3Revenue: last3, revenueChange: last3 / first3 - 1, gmFirst3, gmLast3, gmChange: gmLast3 - gmFirst3, annualizedGrowth: Math.pow(1 + a.growth, 12) - 1 },
      anomalies: detectAnomalies(h),
    };
  }

  /** Flag months where a line item moved unusually versus its own history (robust z-score on month-over-month % change). */
  function detectAnomalies(h) {
    const out = [];
    const lines = [['revenue', 'Revenue'], ['cogs', 'Cost of goods sold'], ['payroll', 'Payroll'], ['rent', 'Rent'], ['otherOpex', 'Other operating expenses']];
    for (const [key, label] of lines) {
      const vals = h.map((m) => m[key] || 0);
      if (vals.some((v) => v <= 0)) continue;
      const ch = vals.slice(1).map((v, i) => v / vals[i] - 1);
      if (ch.length < 5) continue;
      const z = robustZ(ch);
      let lastFlag = -2;
      z.forEach((zz, i) => {
        // skip the month that merely reverses a flagged spike
        if (lastFlag === i - 1 && Math.sign(ch[i]) !== Math.sign(ch[i - 1])) return;
        if (Math.abs(zz) >= 3.5 && Math.abs(ch[i]) >= 0.08) {
          lastFlag = i;
          out.push({ line: label, key, month: h[i + 1].month, change: ch[i], z: zz });
        }
      });
    }
    return out;
  }

  // ---------- decisions ----------
  const inWindow = (t, start, months) => t >= start && (months == null || t < start + months);
  const DECISIONS = {
    hire: {
      label: 'Hire staff', group: 'Growth',
      summary: (p) => `Hire ${p.count} @ ${money(p.salary)}/yr from month ${p.start}`,
      params: [
        { key: 'count', label: 'Number of people', type: 'int', def: 2, min: 1, max: 100 },
        { key: 'salary', label: 'Annual salary per person', type: 'money', def: 60000, min: 0 },
        { key: 'burden', label: 'Benefits & payroll taxes', type: 'pct', def: 0.25, min: 0, max: 1 },
        { key: 'revPerHire', label: 'Monthly revenue each new hire adds (at full speed)', type: 'money', def: 0, min: 0 },
        { key: 'ramp', label: 'Months to full productivity', type: 'int', def: 3, min: 1, max: 24 },
        { key: 'start', label: 'Start month', type: 'month', def: 1 },
      ],
      effect(p, t) {
        if (t < p.start) return {};
        const k = Math.min(1, (t - p.start + 1) / Math.max(1, p.ramp));
        return { opexAdd: (p.count * p.salary * (1 + p.burden)) / 12, revAdd: p.count * p.revPerHire * k };
      },
    },
    loan: {
      label: 'Take a loan', group: 'Financing',
      summary: (p) => `Borrow ${money(p.amount)} at ${(p.apr * 100).toFixed(1)}% for ${p.term} mo`,
      params: [
        { key: 'amount', label: 'Loan amount', type: 'money', def: 100000, min: 0 },
        { key: 'apr', label: 'Interest rate (APR)', type: 'pct', def: 0.09, min: 0, max: 0.6 },
        { key: 'term', label: 'Term (months)', type: 'int', def: 60, min: 1, max: 360 },
        { key: 'start', label: 'Funding month', type: 'month', def: 1 },
      ],
      effect(p, t) {
        if (t !== p.start || p.amount <= 0) return {};
        return { newLoans: [{ name: 'New loan', balance: p.amount, apr: p.apr, payment: pmt(p.apr / 12, p.term, p.amount), from: t }] };
      },
    },
    price: {
      label: 'Change prices', group: 'Growth',
      summary: (p) => `Prices ${p.change >= 0 ? '+' : ''}${(p.change * 100).toFixed(1)}% from month ${p.start}`,
      params: [
        { key: 'change', label: 'Price change', type: 'pct', def: 0.05, min: -0.9, max: 2 },
        { key: 'elasticity', label: 'Price sensitivity (elasticity)', type: 'num', def: -1.0, min: -6, max: 0, step: 0.1,
          help: 'How much sales volume moves for each 1% price change. −1.0 means a 5% price rise loses 5% of volume. Commodity products ≈ −2, loyal/specialty customers ≈ −0.5.' },
        { key: 'start', label: 'Start month', type: 'month', def: 1 },
      ],
      effect(p, t) {
        if (t < p.start) return {};
        return { priceMult: 1 + p.change, volMult: Math.max(0, 1 + p.elasticity * p.change) };
      },
    },
    equipment: {
      label: 'Buy equipment', group: 'Investment',
      summary: (p) => `Buy ${money(p.cost)} equipment in month ${p.start}`,
      params: [
        { key: 'cost', label: 'Purchase cost', type: 'money', def: 50000, min: 0 },
        { key: 'life', label: 'Useful life (years)', type: 'int', def: 7, min: 1, max: 40 },
        { key: 'savings', label: 'Monthly operating cost savings', type: 'money', def: 0, min: 0 },
        { key: 'revLift', label: 'Monthly revenue it adds', type: 'money', def: 0, min: 0 },
        { key: 'start', label: 'Purchase month', type: 'month', def: 1 },
      ],
      effect(p, t) {
        const e = {};
        if (t === p.start) e.capex = p.cost;
        if (t >= p.start && t < p.start + p.life * 12) e.depAdd = p.cost / (p.life * 12);
        if (t > p.start) { e.opexAdd = -p.savings; e.revAdd = p.revLift; }
        return e;
      },
    },
    expansion: {
      label: 'Open a location / product line', group: 'Investment',
      summary: (p) => `Expand: ${money(p.capex)} upfront, ${money(p.fixedCost)}/mo costs`,
      params: [
        { key: 'capex', label: 'Upfront build-out cost', type: 'money', def: 150000, min: 0 },
        { key: 'fixedCost', label: 'Added monthly fixed costs (staff, rent…)', type: 'money', def: 20000, min: 0 },
        { key: 'matureRevenue', label: 'Monthly revenue once established', type: 'money', def: 45000, min: 0 },
        { key: 'mature', label: 'Months to reach that revenue', type: 'int', def: 6, min: 1, max: 36 },
        { key: 'start', label: 'Opening month', type: 'month', def: 2 },
      ],
      effect(p, t) {
        const e = {};
        if (t === p.start) e.capex = p.capex;
        if (t >= p.start) {
          e.depAdd = p.capex / 120; // 10-year straight line
          e.opexAdd = p.fixedCost;
          e.revAdd = p.matureRevenue * Math.min(1, (t - p.start + 1) / Math.max(1, p.mature));
        }
        return e;
      },
    },
    marketing: {
      label: 'Marketing campaign', group: 'Growth',
      summary: (p) => `${money(p.spend)}/mo marketing for ${p.months} mo, +${(p.lift * 100).toFixed(0)}% sales`,
      params: [
        { key: 'spend', label: 'Monthly spend', type: 'money', def: 8000, min: 0 },
        { key: 'months', label: 'Campaign length (months)', type: 'int', def: 6, min: 1, max: 60 },
        { key: 'lift', label: 'Expected sales lift during campaign', type: 'pct', def: 0.08, min: 0, max: 3 },
        { key: 'retain', label: 'Share of lift kept after it ends', type: 'pct', def: 0.4, min: 0, max: 1 },
        { key: 'start', label: 'Start month', type: 'month', def: 1 },
      ],
      effect(p, t) {
        if (t < p.start) return {};
        if (inWindow(t, p.start, p.months)) {
          const ramp = Math.min(1, (t - p.start + 1) / 2); // lift builds over ~2 months
          return { opexAdd: p.spend, volMult: 1 + p.lift * ramp };
        }
        return { volMult: 1 + p.lift * p.retain };
      },
    },
    costcut: {
      label: 'Cut operating costs', group: 'Efficiency',
      summary: (p) => `Save ${money(p.savings)}/mo (one-time cost ${money(p.oneTime)})`,
      params: [
        { key: 'savings', label: 'Monthly savings', type: 'money', def: 10000, min: 0 },
        { key: 'oneTime', label: 'One-time cost to make the cut (severance, fees)', type: 'money', def: 15000, min: 0 },
        { key: 'start', label: 'Start month', type: 'month', def: 1 },
      ],
      effect(p, t) {
        const e = {};
        if (t === p.start) e.oneTimeExp = p.oneTime;
        if (t >= p.start) e.opexAdd = -p.savings;
        return e;
      },
    },
    workingCapital: {
      label: 'Change payment terms / inventory', group: 'Efficiency',
      summary: (p) => [wc(p.dso, 'customers pay', 'later', 'sooner'), wc(p.dio, 'stock held', 'longer', 'shorter'), wc(p.dpo, 'suppliers paid', 'later', 'sooner'), p.discount ? `${(p.discount * 100).toFixed(1)}% early-pay discount` : null].filter(Boolean).join(', ') || 'No change yet',
      params: [
        { key: 'dso', label: 'Change in days to collect from customers', type: 'num', def: -10, min: -365, max: 365, step: 1, help: 'Negative = customers pay you faster (frees cash).' },
        { key: 'dio', label: 'Change in days of inventory held', type: 'num', def: 0, min: -365, max: 365, step: 1, help: 'Negative = carry less stock (frees cash).' },
        { key: 'dpo', label: 'Change in days you take to pay suppliers', type: 'num', def: 0, min: -365, max: 365, step: 1, help: 'Positive = pay suppliers later (frees cash).' },
        { key: 'discount', label: 'Early-payment discount offered (cost, % of sales)', type: 'pct', def: 0, min: 0, max: 0.2 },
        { key: 'start', label: 'Start month', type: 'month', def: 1 },
      ],
      effect(p, t) {
        if (t < p.start) return {};
        const k = Math.min(1, (t - p.start + 1) / 3); // phased in over 3 months
        return { dsoDelta: p.dso * k, dioDelta: p.dio * k, dpoDelta: p.dpo * k, priceMult: 1 - p.discount };
      },
    },
    supplier: {
      label: 'Supplier cost change', group: 'Efficiency',
      summary: (p) => `Unit costs ${p.change >= 0 ? '+' : ''}${(p.change * 100).toFixed(1)}% from month ${p.start}`,
      params: [
        { key: 'change', label: 'Change in cost of goods per unit', type: 'pct', def: -0.03, min: -0.9, max: 2 },
        { key: 'start', label: 'Start month', type: 'month', def: 1 },
      ],
      effect(p, t) { return t >= p.start ? { cogsMult: 1 + p.change } : {}; },
    },
    customerLoss: {
      label: 'Stress test: lose sales', group: 'Stress test',
      summary: (p) => `Lose ${(p.share * 100).toFixed(0)}% of sales from month ${p.start}`,
      params: [
        { key: 'share', label: 'Share of sales lost (e.g. a big customer)', type: 'pct', def: 0.15, min: 0, max: 1 },
        { key: 'start', label: 'Starting month', type: 'month', def: 3 },
      ],
      effect(p, t) { return t >= p.start ? { volMult: 1 - p.share } : {}; },
    },
    oneOff: {
      label: 'One-time income or expense', group: 'Other',
      summary: (p) => `${p.amount >= 0 ? 'Receive' : 'Pay'} ${money(Math.abs(p.amount))} in month ${p.month}`,
      params: [
        { key: 'amount', label: 'Amount (+ income, − expense)', type: 'money', def: -20000 },
        { key: 'month', label: 'Month', type: 'month', def: 3 },
      ],
      effect(p, t) { return t === p.month ? { oneTimeExp: -p.amount } : {}; },
    },
  };
  function money(v) {
    const a = Math.abs(v), s = v < 0 ? '−' : '';
    if (a >= 1e6) return `${s}$${(a / 1e6).toFixed(a >= 1e7 ? 0 : 1)}M`;
    if (a >= 1e3) return `${s}$${(a / 1e3).toFixed(a >= 1e5 ? 0 : 1)}k`.replace('.0k', 'k');
    return `${s}$${a.toFixed(0)}`;
  }
  function wc(d, what, up, down) { return d ? `${what} ${Math.abs(d)} days ${d > 0 ? up : down}` : null; }
  function fmtDays(d) { return d === 0 ? 'unchanged' : `${d > 0 ? '+' : '−'}${Math.abs(d)} days`; }

  function newDecision(type, overrides) {
    const def = DECISIONS[type];
    const params = {};
    for (const p of def.params) params[p.key] = p.def;
    return { id: Math.random().toString(36).slice(2, 9), type, params: Object.assign(params, overrides || {}) };
  }

  function combineEffects(decisions, t) {
    const e = { volMult: 1, priceMult: 1, cogsMult: 1, revAdd: 0, opexAdd: 0, oneTimeExp: 0, capex: 0, depAdd: 0, dsoDelta: 0, dioDelta: 0, dpoDelta: 0, newLoans: [] };
    for (const d of decisions) {
      if (d.enabled === false) continue;
      const def = DECISIONS[d.type];
      if (!def) continue;
      const x = def.effect(d.params, t) || {};
      if (x.volMult != null) e.volMult *= x.volMult;
      if (x.priceMult != null) e.priceMult *= x.priceMult;
      if (x.cogsMult != null) e.cogsMult *= x.cogsMult;
      for (const k of ['revAdd', 'opexAdd', 'oneTimeExp', 'capex', 'depAdd', 'dsoDelta', 'dioDelta', 'dpoDelta']) if (x[k]) e[k] += x[k];
      if (x.newLoans) e.newLoans.push(...x.newLoans);
    }
    return e;
  }

  // ---------- projection ----------
  /**
   * Project one path month by month.
   * shocks: null for the expected path, or a function returning standard normals (Monte Carlo).
   */
  function projectPath(company, A, decisions, months, shocks, volMult = 1) {
    const b0 = company.balance;
    const state = {
      cash: b0.cash, ar: b0.ar, inventory: b0.inventory, ap: b0.ap,
      otherCurrentAssets: b0.otherCurrentAssets || 0, fixedAssets: b0.fixedAssets || 0, otherAssets: b0.otherAssets || 0, accrued: b0.accrued || 0,
    };
    const loans = b0.debt > 0 ? [{ name: 'Existing debt', balance: b0.debt, apr: b0.debtApr || 0, payment: b0.debtPayment || 0, from: 0 }] : [];
    const PHI = 0.6; // persistence of revenue deviations from trend
    const innovSD = A.revVol * volMult * Math.sqrt(1 - PHI * PHI);
    const gPath = shocks ? Math.exp(Math.log(1 + A.growth) + A.growthSE * volMult * shocks()) - 1 : A.growth;
    let dev = 0; // current log deviation from trend
    let trendRev = A.startRevenue;
    const rows = [];
    let minCash = state.cash, minCashMonth = 0, cashOutMonth = null;
    for (let t = 1; t <= months; t++) {
      trendRev *= 1 + gPath;
      let gm = A.grossMargin;
      if (shocks) {
        dev = PHI * dev + innovSD * shocks();
        gm = Math.min(0.98, Math.max(-0.5, gm + A.gmVol * volMult * shocks()));
      }
      // mean-preserving lognormal deviation
      const baseRev = trendRev * (shocks ? Math.exp(dev - 0.5 * (A.revVol * volMult) ** 2) : 1);
      const e = combineEffects(decisions, t);
      const units = baseRev * e.volMult + e.revAdd; // sales at today's prices
      const revenue = units * e.priceMult;
      const cogs = units * (1 - gm) * e.cogsMult;
      const opex = Math.max(0, A.fixedOpex * Math.pow(1 + A.costInflation, t / 12) + e.opexAdd);
      const oneTime = e.oneTimeExp;
      const ebitda = revenue - cogs - opex - oneTime;
      const dep = A.depreciation + e.depAdd;
      const ebit = ebitda - dep;
      // debt service on loans that existed before this month
      let interest = 0, principal = 0;
      for (const l of loans) {
        if (l.balance <= 0.005 || l.from >= t) continue;
        const int = (l.balance * l.apr) / 12;
        const pr = Math.min(l.balance, Math.max(0, l.payment - int));
        interest += int; principal += pr; l.balance -= pr;
      }
      let proceeds = 0;
      for (const nl of e.newLoans) { loans.push(Object.assign({}, nl)); proceeds += nl.balance; }
      const ebt = ebit - interest;
      const tax = Math.max(0, ebt) * A.taxRate;
      const netIncome = ebt - tax;
      // working capital tied to activity
      const dso = Math.max(0, A.dso + e.dsoDelta), dio = Math.max(0, A.dio + e.dioDelta), dpo = Math.max(0, A.dpo + e.dpoDelta);
      const ar = (revenue * dso) / DPM, inv = (cogs * dio) / DPM, ap = (cogs * dpo) / DPM;
      const dWC = (ar - state.ar) + (inv - state.inventory) - (ap - state.ap);
      const ocf = netIncome + dep - dWC;
      const capex = A.capex + e.capex;
      const fcf = ocf - capex;
      const netCash = fcf + proceeds - principal;
      state.cash += netCash;
      state.ar = ar; state.inventory = inv; state.ap = ap;
      state.fixedAssets = Math.max(0, state.fixedAssets + capex - dep);
      const debt = sum(loans.map((l) => l.balance));
      if (state.cash < minCash) { minCash = state.cash; minCashMonth = t; }
      if (cashOutMonth === null && state.cash < 0) cashOutMonth = t;
      rows.push({
        t, revenue, cogs, grossProfit: revenue - cogs, opex, oneTime, ebitda, dep, ebit, interest, ebt, tax, netIncome,
        dWC, ocf, capex, fcf, proceeds, principal, netCash, cash: state.cash, debt,
        ar, inventory: inv, ap, fixedAssets: state.fixedAssets, grossMarginPct: revenue ? (revenue - cogs) / revenue : 0,
      });
    }
    return { rows, minCash, minCashMonth, cashOutMonth, endState: state, loans };
  }

  /** Ratios at a projected month, using the trailing 3 months annualized. */
  function ratiosAt(company, path, t) {
    const win = path.rows.slice(Math.max(0, t - 3), t);
    const r = path.rows[t - 1];
    const flows = ['revenue', 'cogs', 'grossProfit', 'ebitda', 'ebit', 'interest', 'principal', 'netIncome'].reduce((o, k) => (o[k] = sum(win.map((x) => x[k])), o), {});
    // rebuild loan balances at month t from the path is not stored per loan; approximate with a single loan at the recorded debt
    // using the blended payment so the current-portion estimate stays sensible.
    const blendedPay = win.length ? sum(win.map((x) => x.interest + x.principal)) / win.length : 0;
    const blendedApr = r.debt > 0 && win.length ? (sum(win.map((x) => x.interest)) / win.length) * 12 / Math.max(1, r.debt) : 0;
    const loans = r.debt > 0 ? [{ balance: r.debt, apr: blendedApr, payment: blendedPay }] : [];
    const b = company.balance;
    // A negative cash balance means the plan needs outside funding: treat the gap as short-term borrowing.
    const gap = Math.max(0, -r.cash);
    if (gap > 0) loans.push({ balance: gap, apr: 0, payment: gap }); // due within 12 months
    const bal = { cash: Math.max(0, r.cash), ar: r.ar, inventory: r.inventory, ap: r.ap, otherCurrentAssets: b.otherCurrentAssets || 0, fixedAssets: r.fixedAssets, otherAssets: b.otherAssets || 0, accrued: b.accrued || 0 };
    const out = addCCC(ratioSet(bal, flows, win.length, loans));
    out.fundingGap = gap;
    return out;
  }

  /** Monte Carlo: same random numbers for every scenario (common random numbers) so differences come from the decision, not luck. */
  function monteCarlo(company, A, decisions, opts) {
    const { months = 12, paths = 1000, seed = 20261117, volMult = 1 } = opts || {};
    const cashByMonth = Array.from({ length: months }, () => new Float64Array(paths));
    const endCash = new Float64Array(paths);
    const cumNI = new Float64Array(paths);
    const outByMonth = new Float64Array(months); // cumulative count of paths that have gone below zero by month t
    let cashOut = 0;
    for (let i = 0; i < paths; i++) {
      const z = normalGen(seed + i * 7919);
      const p = projectPath(company, A, decisions, months, z, volMult);
      p.rows.forEach((r, k) => (cashByMonth[k][i] = r.cash));
      endCash[i] = p.rows[months - 1].cash;
      cumNI[i] = sum(p.rows.map((r) => r.netIncome));
      if (p.cashOutMonth !== null) { cashOut++; for (let k = p.cashOutMonth - 1; k < months; k++) outByMonth[k]++; }
    }
    const band = cashByMonth.map((arr) => {
      const s = Array.from(arr).sort((a, b) => a - b);
      return { p10: percentile(s, 10), p25: percentile(s, 25), p50: percentile(s, 50), p75: percentile(s, 75), p90: percentile(s, 90) };
    });
    const endSorted = Array.from(endCash).sort((a, b) => a - b);
    const niSorted = Array.from(cumNI).sort((a, b) => a - b);
    return {
      paths, months,
      probCashOut: cashOut / paths,
      probCashOutByMonth: Array.from(outByMonth).map((c) => c / paths),
      band,
      endCash: { p10: percentile(endSorted, 10), p50: percentile(endSorted, 50), p90: percentile(endSorted, 90) },
      cumNetIncome: { p10: percentile(niSorted, 10), p50: percentile(niSorted, 50), p90: percentile(niSorted, 90) },
      probLoss: niSorted.filter((x) => x < 0).length / paths,
    };
  }

  /** Run one scenario end to end. */
  function runScenario(company, scenario, opts) {
    const A = deriveAssumptions(company);
    const months = opts.months || 12;
    const expected = projectPath(company, A, scenario.decisions, months, null);
    const mc = monteCarlo(company, A, scenario.decisions, opts);
    const endRatios = ratiosAt(company, expected, months);
    // worst debt service coverage across the horizon, on a trailing-12-month basis (how lenders test it)
    let worstDSCR = null, worstDSCRMonth = null;
    const W = Math.min(12, months);
    for (let t = W; t <= months; t++) {
      const w = expected.rows.slice(t - W, t);
      const ds = sum(w.map((r) => r.interest + r.principal));
      if (ds > 0) {
        const v = sum(w.map((r) => r.ebitda)) / ds;
        if (worstDSCR === null || v < worstDSCR) { worstDSCR = v; worstDSCRMonth = t; }
      }
    }
    const totals = ['revenue', 'grossProfit', 'ebitda', 'netIncome', 'fcf', 'capex', 'proceeds'].reduce((o, k) => (o[k] = sum(expected.rows.map((r) => r[k])), o), {});
    const avgOpex = mean(expected.rows.map((r) => r.opex));
    const result = { scenario, assumptions: A, expected, mc, endRatios, worstDSCR, worstDSCRMonth, totals, avgOpex, months };
    result.flags = scenarioFlags(result);
    return result;
  }

  // ---------- risk identification ----------
  const SEV_ORDER = { critical: 0, serious: 1, warning: 2, good: 3 };
  const pct = (x, d = 0) => `${(x * 100).toFixed(d)}%`;
  const x2 = (x) => `${x.toFixed(2)}×`;

  function scenarioFlags(r) {
    const f = [];
    const mc = r.mc, ex = r.expected;
    if (mc.probCashOut >= 0.25) f.push({ sev: 'critical', title: `${pct(mc.probCashOut)} chance of running out of cash`, detail: `In ${pct(mc.probCashOut)} of ${mc.paths} simulated futures, the cash balance drops below zero within ${r.months} months.`, metric: 'probCashOut' });
    else if (mc.probCashOut >= 0.10) f.push({ sev: 'serious', title: `${pct(mc.probCashOut)} chance of running out of cash`, detail: `A meaningful share of simulated futures run out of cash. Consider a larger cash buffer or a credit line before committing.`, metric: 'probCashOut' });
    else if (mc.probCashOut >= 0.03) f.push({ sev: 'warning', title: `${pct(mc.probCashOut)} chance of running out of cash`, detail: `Low but not negligible. A bad stretch of sales could exhaust cash.`, metric: 'probCashOut' });
    if (ex.cashOutMonth) f.push({ sev: 'critical', title: `Expected path runs out of cash in month ${ex.cashOutMonth}`, detail: `Even without any bad luck, the plan as entered drains cash below zero by month ${ex.cashOutMonth}.`, metric: 'cash' });
    else if (ex.minCash < r.avgOpex) f.push({ sev: 'warning', title: 'Thin cash cushion', detail: ex.minCashMonth === 0 ? `Cash never gets above today's ${money(ex.minCash)} cushion, which is less than one month of operating expenses (${money(r.avgOpex)}).` : `Expected cash falls to ${money(ex.minCash)} in month ${ex.minCashMonth}, less than one month of operating expenses (${money(r.avgOpex)}).`, metric: 'cash' });
    if (r.worstDSCR !== null) {
      if (r.worstDSCR < 0) f.push({ sev: 'critical', title: 'Operating losses leave nothing to pay debt', detail: `In the 12 months to month ${r.worstDSCRMonth}, EBITDA is negative, so loan payments must come out of the cash balance. Lenders typically want debt service coverage (DSCR) of at least 1.25×.`, metric: 'dscr' });
      else if (r.worstDSCR < 1) f.push({ sev: 'critical', title: `Debt payments exceed operating cash (DSCR ${x2(r.worstDSCR)})`, detail: `In the 12 months to month ${r.worstDSCRMonth}, earnings before interest, taxes, depreciation and amortization (EBITDA) do not cover loan payments. Lenders typically want at least 1.25×.`, metric: 'dscr' });
      else if (r.worstDSCR < 1.25) f.push({ sev: 'serious', title: `Debt coverage below lender comfort (DSCR ${x2(r.worstDSCR)})`, detail: `Many banks require a debt service coverage ratio of 1.25× or more; this would likely breach a typical covenant in the 12 months to month ${r.worstDSCRMonth}.`, metric: 'dscr' });
    }
    const er = r.endRatios;
    if (er.fundingGap > 0) f.push({ sev: 'critical', title: `Needs ${money(er.fundingGap)} of outside funding`, detail: `By month ${r.months} the plan has spent more cash than the business has. End-of-period ratios treat this gap as short-term borrowing.`, metric: 'cash' });
    if (er.equity <= 0) f.push({ sev: 'critical', title: 'Liabilities exceed assets', detail: 'Projected equity is negative: the business would owe more than it owns.', metric: 'equity' });
    else if (er.debtToEquity !== null && er.debtToEquity > 3) f.push({ sev: 'serious', title: `High leverage (debt-to-equity ${x2(er.debtToEquity)})`, detail: 'Heavy borrowing relative to owner capital leaves little room for a downturn.', metric: 'debtToEquity' });
    else if (er.debtToEquity !== null && er.debtToEquity > 2) f.push({ sev: 'warning', title: `Elevated leverage (debt-to-equity ${x2(er.debtToEquity)})`, detail: 'Debt is more than twice owner equity.', metric: 'debtToEquity' });
    if (er.interestCoverage !== null && er.interestCoverage < 0) f.push({ sev: 'serious', title: 'Operating loss: interest not covered', detail: 'At the end of the horizon the business has an operating loss, so interest is paid from cash rather than earnings.', metric: 'interestCoverage' });
    else if (er.interestCoverage !== null && er.interestCoverage < 1.5) f.push({ sev: 'serious', title: `Weak interest coverage (${x2(er.interestCoverage)})`, detail: 'Operating profit barely covers interest at the end of the horizon.', metric: 'interestCoverage' });
    if (er.currentRatio !== null && er.currentRatio < 1) f.push({ sev: 'warning', title: `Current ratio below 1 (${x2(er.currentRatio)})`, detail: 'Short-term obligations exceed short-term assets at the end of the horizon.', metric: 'currentRatio' });
    if (mc.probLoss >= 0.5) f.push({ sev: 'warning', title: `Likely net loss over the period (${pct(mc.probLoss)} of futures)`, detail: `Median cumulative net income is ${money(mc.cumNetIncome.p50)}.`, metric: 'netIncome' });
    const gmDrop = r.assumptions.grossMargin - (er.grossMargin ?? r.assumptions.grossMargin);
    if (gmDrop > 0.03) f.push({ sev: 'warning', title: `Gross margin falls ${pct(gmDrop, 1)} points`, detail: 'Each sale earns less. Make sure the extra volume is worth it.', metric: 'grossMargin' });
    if (!f.some((x) => x.sev !== 'good') ) f.push({ sev: 'good', title: 'No major warning signs', detail: `Cash-out risk is ${pct(mc.probCashOut)} and no ratio breaches the app's warning thresholds.`, metric: 'overall' });
    if (mc.probCashOut < 0.02 && r.mc.endCash.p10 > r.expected.rows[0].cash * 0.9) f.push({ sev: 'good', title: 'Cash holds up even in bad scenarios', detail: `In the pessimistic case (10th percentile) cash ends at ${money(r.mc.endCash.p10)}.`, metric: 'cash' });
    return f.sort((a, b) => SEV_ORDER[a.sev] - SEV_ORDER[b.sev]);
  }

  function todayFlags(today) {
    const f = [];
    const r = today.ratios, tr = today.trend;
    if (tr.revenueChange <= -0.05) f.push({ sev: 'serious', title: `Sales are shrinking (${pct(tr.revenueChange)} over the period)`, detail: `Average monthly revenue fell from ${money(tr.first3Revenue)} (first 3 months) to ${money(tr.last3Revenue)} (last 3).` });
    else if (tr.revenueChange >= 0.1) f.push({ sev: 'good', title: `Sales are growing (${pct(tr.revenueChange)})`, detail: `Average monthly revenue rose from ${money(tr.first3Revenue)} to ${money(tr.last3Revenue)}.` });
    if (tr.gmChange <= -0.02) f.push({ sev: 'warning', title: `Gross margin is slipping (${pct(tr.gmChange, 1)} pts)`, detail: `Margin moved from ${pct(tr.gmFirst3, 1)} to ${pct(tr.gmLast3, 1)}. Costs are rising faster than prices.` });
    if (r.netMargin !== null && r.netMargin < 0) f.push({ sev: 'serious', title: `Losing money (net margin ${pct(r.netMargin, 1)})`, detail: `Net income over the period was ${money(today.flows.netIncome)}.` });
    if (r.runwayMonths !== null && r.runwayMonths < 6) f.push({ sev: 'critical', title: `Cash runway about ${r.runwayMonths.toFixed(1)} months`, detail: `At the recent burn rate (${money(-r.monthlyNetCash)}/month) cash runs out in under six months.` });
    else if (r.runwayMonths !== null && r.runwayMonths < 12) f.push({ sev: 'serious', title: `Cash runway about ${r.runwayMonths.toFixed(1)} months`, detail: `At ${money(-r.monthlyNetCash)}/month burn, cash lasts under a year.` });
    if (r.currentRatio !== null && r.currentRatio < 1) f.push({ sev: 'serious', title: `Current ratio ${x2(r.currentRatio)}`, detail: 'Bills due within a year exceed cash and other short-term assets.' });
    else if (r.currentRatio !== null && r.currentRatio < 1.2) f.push({ sev: 'warning', title: `Tight liquidity (current ratio ${x2(r.currentRatio)})`, detail: 'Little buffer between short-term assets and short-term obligations.' });
    if (r.quickRatio !== null && r.quickRatio < 0.5 && r.dio && r.dio > 60) f.push({ sev: 'warning', title: `Cash is tied up in inventory (${r.dio.toFixed(0)} days on hand)`, detail: `Quick ratio is only ${x2(r.quickRatio)}; most short-term assets are stock that must be sold first.` });
    if (r.dso !== null && r.dso > 60) f.push({ sev: 'warning', title: `Customers pay slowly (${r.dso.toFixed(0)} days)`, detail: 'Receivables average more than two months of sales.' });
    if (r.dscr !== null && r.dscr < 0) f.push({ sev: 'critical', title: 'Operating losses, but loan payments are due', detail: 'EBITDA is negative, so every loan payment comes straight out of cash.' });
    else if (r.dscr !== null && r.dscr < 1.25) f.push({ sev: r.dscr < 1 ? 'critical' : 'serious', title: `Debt coverage ${x2(r.dscr)}`, detail: 'Operating earnings provide little margin over loan payments (lenders usually want 1.25×+).' });
    if (r.debtToEquity !== null && r.debtToEquity > 2) f.push({ sev: 'warning', title: `High leverage (debt-to-equity ${x2(r.debtToEquity)})`, detail: 'Debt is more than twice the owners’ stake.' });
    if (r.equity <= 0) f.push({ sev: 'critical', title: 'Negative equity', detail: 'Liabilities exceed assets.' });
    for (const a of today.anomalies) f.push({ sev: 'warning', title: `Unusual ${a.line.toLowerCase()} in ${a.month} (${a.change >= 0 ? '+' : ''}${pct(a.change)})`, detail: `This month-over-month change is far outside the normal pattern (robust z-score ${a.z.toFixed(1)}). Worth checking whether it is a one-off or an error.` });
    if (r.netMargin !== null && r.netMargin > 0.1) f.push({ sev: 'good', title: `Healthy profitability (net margin ${pct(r.netMargin, 1)})`, detail: 'The business keeps more than 10 cents of every sales dollar.' });
    if (r.currentRatio !== null && r.currentRatio >= 2) f.push({ sev: 'good', title: `Strong liquidity (current ratio ${x2(r.currentRatio)})`, detail: 'Short-term assets comfortably cover short-term obligations.' });
    return f.sort((a, b) => SEV_ORDER[a.sev] - SEV_ORDER[b.sev]);
  }

  return {
    DPM, DECISIONS, sum, mean, std, median, percentile, linreg, pmt, robustZ, mulberry32, normalGen,
    deriveAssumptions, analyzeToday, detectAnomalies, newDecision, combineEffects, projectPath, ratiosAt,
    monteCarlo, runScenario, scenarioFlags, todayFlags, principalDueNext, money,
  };
});

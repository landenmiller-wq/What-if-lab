import sys, json
from playwright.sync_api import sync_playwright
url = 'file:///home/claude/decision-lab/dist/index.html'
errs = []
with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
    pg = b.new_page(viewport={'width': 1400, 'height': 1000})
    pg.on('console', lambda m: errs.append(f'{m.type}: {m.text}') if m.type in ('error', 'warning') else None)
    pg.on('pageerror', lambda e: errs.append(f'pageerror: {e}'))
    pg.goto(url); pg.wait_for_timeout(1200)
    pg.screenshot(path='shots/lab.png', full_page=True)
    print('verdicts:', pg.locator('#verdicts .big').all_inner_texts())
    for tab in ['today', 'detail', 'ai', 'data', 'method']:
        pg.click(f'nav.tabs button[data-view={tab}]'); pg.wait_for_timeout(400)
        pg.screenshot(path=f'shots/{tab}.png', full_page=True)
    # interaction: change loan amount in Option A and confirm verdict changes
    pg.click('nav.tabs button[data-view=lab]'); pg.wait_for_timeout(200)
    before = pg.locator('#verdicts .big').all_inner_texts()
    pg.locator('[data-toggle]').nth(1).click(); pg.wait_for_timeout(200)  # open loan card in A
    inp = pg.locator('input[data-key=amount]').first
    inp.fill('300000'); inp.dispatch_event('input'); pg.wait_for_timeout(700)
    after = pg.locator('#verdicts .big').all_inner_texts()
    print('loan 180k->300k verdicts:', before, '->', after)
    # add decision to B
    pg.select_option('select[data-add=b]', 'customerLoss'); pg.wait_for_timeout(700)
    print('after adding stress test to B:', pg.locator('#verdicts .big').all_inner_texts())
    pg.screenshot(path='shots/lab_edit.png', full_page=False)
    # switch company + horizon
    pg.select_option('#companySel', 'northwind'); pg.wait_for_timeout(800)
    print('northwind:', pg.locator('#verdicts .big').all_inner_texts())
    pg.screenshot(path='shots/lab_northwind.png', full_page=True)
    pg.select_option('#companySel', 'ledgerly'); pg.wait_for_timeout(800)
    pg.select_option('#horizonSel', '18'); pg.wait_for_timeout(800)
    print('ledgerly 18m:', pg.locator('#verdicts .big').all_inner_texts())
    # AI fallback
    pg.click('[data-goto-ai=compare]'); pg.wait_for_timeout(500)
    print('AI pill:', pg.locator('#aiPill').inner_text(), '| status:', pg.locator('#aiStatus').inner_text())
    pg.screenshot(path='shots/ai_fallback.png', full_page=True)
    # CSV import
    pg.click('nav.tabs button[data-view=data]')
    pg.fill('#csvIn', 'month,revenue,cogs,payroll,rent,other_opex\nJan 2026,"$50,000",20000,15000,4000,6000\nFeb 2026,52000,21000,15000,4000,6000\nMar 2026,55000,22000,15500,4000,6100\nApr 2026,54000,21500,15500,4000,6000')
    pg.click('#importBtn'); pg.wait_for_timeout(700)
    print('csv:', pg.locator('#csvMsg').inner_text(), '| rows:', pg.locator('#histTbl tbody tr').count())
    # error state: zero revenue
    pg.locator('#histTbl input[data-k=revenue]').first.fill('0'); pg.wait_for_timeout(600)
    print('error box:', pg.locator('#errMsg').inner_text() if pg.locator('#errMsg').count() else 'none')
    pg.locator('#histTbl input[data-k=revenue]').first.fill('50000'); pg.wait_for_timeout(600)
    print('error cleared:', pg.locator('#errBox').count() == 0)
    # mobile
    m = b.new_page(viewport={'width': 390, 'height': 900}); m.goto(url); m.wait_for_timeout(1000)
    m.screenshot(path='shots/mobile.png', full_page=False)
    # dark
    d = b.new_page(viewport={'width': 1400, 'height': 1000}, color_scheme='dark'); d.goto(url + '#today'); d.wait_for_timeout(1000)
    d.screenshot(path='shots/dark_today.png', full_page=False)
    b.close()
print('console issues:', json.dumps([e for e in errs if 'fonts.g' not in e], indent=1))

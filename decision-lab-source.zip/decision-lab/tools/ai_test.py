from playwright.sync_api import sync_playwright
mock = """
window.__prompts = [];
window.claude = { use: async (name) => name === 'sample' ? Object.assign(async (input, opts) => {
  window.__prompts.push(input);
  const data = JSON.parse(input.split('DATA\\n')[1]);
  const a = data.scenarios[1], base = data.scenarios[0];
  const txt = `## Bottom line\\n**${a.name}** has a ${a.chance_of_running_out_of_cash_pct}% chance of running out of cash versus ${base.chance_of_running_out_of_cash_pct}% today, ending near $${Math.round(a.expected_end_cash/1000)}k.\\n## Option by option\\n- Baseline ends with $${base.expected_end_cash.toLocaleString()}.\\n- A made-up figure: $999,999 and 73.2%.`;
  for (let i = 10; i <= txt.length; i += 40) { opts.onText({ text: txt.slice(0, i) }); await new Promise(r => setTimeout(r, 5)); }
  return { text: txt, truncated: false };
}, { json: async () => ({}) }) : null };
"""
with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
    pg = b.new_page(viewport={'width': 1400, 'height': 1000})
    errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.add_init_script(mock)
    pg.goto('file:///home/claude/decision-lab/dist/index.html'); pg.wait_for_timeout(1500)
    print('status:', pg.locator('#aiStatus').inner_text())
    pg.click('[data-goto-ai=compare]'); pg.wait_for_timeout(1500)
    print('pill:', pg.locator('#aiPill').inner_text())
    print('check:', pg.locator('#aiCheck').inner_text())
    print('note:', pg.locator('#aiNoteText').inner_text()[:60])
    pr = pg.evaluate('window.__prompts[0]')
    print('prompt has rules:', 'Use ONLY the figures in DATA' in pr, '| prompt chars:', len(pr))
    pg.screenshot(path='shots/ai_mock.png', full_page=True)
    pg.select_option('#companySel', 'northwind'); pg.wait_for_timeout(600)
    pg.click('[data-ai=premortem]'); pg.wait_for_timeout(1500)
    pr = pg.evaluate('window.__prompts[1]')
    print('premortem target in prompt:', '"premortem_target": "Discount to win back sales"' in pr)
    print('errors:', errs)
    b.close()

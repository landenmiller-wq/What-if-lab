// Inlines CSS, Chart.js, engine, samples and app into one self-contained dist/index.html
const fs = require('fs'), path = require('path');
const R = (p) => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');
require('./gen-samples.js');
let html = R('src/index.template.html');
const parts = {
  '/*@@STYLES@@*/': R('src/styles.css'),
  '/*@@CHARTJS@@*/': R('node_modules/chart.js/dist/chart.umd.min.js').replace(/\/\/# sourceMappingURL=.*$/m, ''),
  '/*@@ENGINE@@*/': R('src/engine.js'),
  '/*@@SAMPLES@@*/': R('src/samples.js'),
  '/*@@APP@@*/': R('src/app.js'),
};
for (const [k, v] of Object.entries(parts)) html = html.split(k).join(v.replace(/<\/script/gi, '<\\/script'));
fs.mkdirSync(path.join(__dirname, '../dist'), { recursive: true });
fs.writeFileSync(path.join(__dirname, '../dist/index.html'), html);
console.log('dist/index.html', (html.length / 1024).toFixed(0) + ' KB');

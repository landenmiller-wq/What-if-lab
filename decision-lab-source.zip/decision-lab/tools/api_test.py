import json
from playwright.sync_api import sync_playwright
seen = {}
def sse(text):
    ev = [{'type':'message_start','message':{}}, {'type':'content_block_start','index':0,'content_block':{'type':'text','text':''}}]
    for i in range(0, len(text), 25): ev.append({'type':'content_block_delta','index':0,'delta':{'type':'text_delta','text':text[i:i+25]}})
    ev += [{'type':'content_block_stop','index':0},{'type':'message_delta','delta':{'stop_reason':'end_turn'}},{'type':'message_stop'}]
    return ''.join(f"event: {e['type']}\ndata: {json.dumps(e)}\n\n" for e in ev)
def handler(route, request):
    seen['headers'] = request.headers; seen['body'] = json.loads(request.post_data)
    if request.headers.get('x-api-key') == 'sk-ant-bad':
        return route.fulfill(status=401, content_type='application/json', body=json.dumps({'type':'error','error':{'type':'authentication_error','message':'invalid x-api-key'}}), headers={'access-control-allow-origin':'*'})
    route.fulfill(status=200, content_type='text/event-stream', body=sse('## Bottom line\n**Wholesale push** looks safer: **0.0%** cash-out risk.\n- Point two'), headers={'access-control-allow-origin':'*'})
with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
    pg = b.new_page(viewport={'width':1400,'height':1000}); errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.route('https://api.anthropic.com/**', handler)
    pg.goto('file:///home/claude/decision-lab/dist/index.html#ai'); pg.wait_for_timeout(2500)
    print('status before:', pg.locator('#aiStatus').inner_text(), '| key card visible:', pg.locator('#apiCard').is_visible())
    pg.fill('#apiKeyIn', 'sk-ant-bad'); pg.click('#apiSave'); pg.wait_for_timeout(200)
    pg.click('[data-ai=compare]'); pg.wait_for_timeout(1500)
    print('bad key ->', pg.locator('#aiOut').inner_text()[:90])
    pg.fill('#apiKeyIn', 'sk-ant-test-1234'); pg.select_option('#apiModelSel', 'claude-haiku-5-5'); pg.click('#apiSave'); pg.wait_for_timeout(200)
    print('status after:', pg.locator('#aiStatus').inner_text())
    pg.click('[data-ai=compare]'); pg.wait_for_timeout(1500)
    print('pill:', pg.locator('#aiPill').inner_text(), '| out:', pg.locator('#aiOut').inner_text().replace('\n',' | ')[:120])
    print('check:', pg.locator('#aiCheck').inner_text().replace('\n',' '))
    h = seen['headers']; print('headers ok:', h.get('anthropic-dangerous-direct-browser-access')=='true', h.get('anthropic-version'), '| model:', seen['body']['model'], '| stream:', seen['body']['stream'])
    pg.reload(); pg.wait_for_timeout(2500)
    print('persisted after reload:', pg.locator('#aiStatus').inner_text())
    pg.click('#apiClear'); print('after remove:', pg.locator('#aiStatus').inner_text())
    print('errors:', errs)
    b.close()
